"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Edit, Trash2, Plus, Check } from "lucide-react"

interface DetectedField {
  id: string
  name: string
  type: "text" | "number" | "date" | "checkbox" | "signature"
  x: number
  y: number
  width: number
  height: number
  page: number
  confidence: number
  required: boolean
  format?: string
}

interface ProcessedDocument {
  id: string
  name: string
  type: string
  status: string
  fields: DetectedField[]
  confidence: number
}

interface FieldEditorProps {
  document: ProcessedDocument
  onUpdate: (document: ProcessedDocument) => void
  onConfirm: () => void
}

export function FieldEditor({ document, onUpdate, onConfirm }: FieldEditorProps) {
  const [selectedField, setSelectedField] = useState<DetectedField | null>(null)
  const [editingField, setEditingField] = useState<DetectedField | null>(null)

  const handleFieldUpdate = (updatedField: DetectedField) => {
    const updatedFields = document.fields.map((field) => (field.id === updatedField.id ? updatedField : field))
    onUpdate({ ...document, fields: updatedFields })
    setEditingField(null)
    setSelectedField(updatedField)
  }

  const handleFieldDelete = (fieldId: string) => {
    const updatedFields = document.fields.filter((field) => field.id !== fieldId)
    onUpdate({ ...document, fields: updatedFields })
    if (selectedField?.id === fieldId) {
      setSelectedField(null)
    }
  }

  const handleAddField = () => {
    const newField: DetectedField = {
      id: `field-${Date.now()}`,
      name: "ฟิลด์ใหม่",
      type: "text",
      x: 100,
      y: 100,
      width: 150,
      height: 20,
      page: 1,
      confidence: 1.0,
      required: false,
    }
    const updatedFields = [...document.fields, newField]
    onUpdate({ ...document, fields: updatedFields })
    setSelectedField(newField)
    setEditingField(newField)
  }

  const getFieldTypeColor = (type: string) => {
    const colors: Record<string, string> = {
      text: "bg-blue-100 text-blue-800",
      number: "bg-green-100 text-green-800",
      date: "bg-purple-100 text-purple-800",
      checkbox: "bg-orange-100 text-orange-800",
      signature: "bg-red-100 text-red-800",
    }
    return colors[type] || "bg-gray-100 text-gray-800"
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>แก้ไขฟิลด์: {document.name}</CardTitle>
            <div className="flex gap-2">
              <Button onClick={handleAddField} size="sm">
                <Plus className="w-4 h-4 mr-2" />
                เพิ่มฟิลด์
              </Button>
              <Button onClick={onConfirm} className="bg-green-600 hover:bg-green-700">
                <Check className="w-4 h-4 mr-2" />
                ยืนยันเอกสาร
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Field List */}
            <div className="space-y-3">
              <h3 className="font-medium">รายการฟิลด์ ({document.fields.length})</h3>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {document.fields.map((field) => (
                  <div
                    key={field.id}
                    className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                      selectedField?.id === field.id ? "border-primary bg-primary/5" : "border-border hover:bg-muted/50"
                    }`}
                    onClick={() => setSelectedField(field)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Badge className={getFieldTypeColor(field.type)}>{field.type}</Badge>
                        <span className="font-medium text-sm">{field.name}</span>
                      </div>
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation()
                            setEditingField(field)
                          }}
                        >
                          <Edit className="w-3 h-3" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation()
                            handleFieldDelete(field.id)
                          }}
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      หน้า {field.page} • ({field.x}, {field.y}) • {field.width}×{field.height}
                      {field.required && " • จำเป็น"}
                    </div>
                    <div className="text-xs text-muted-foreground">ความมั่นใจ: {Math.round(field.confidence * 100)}%</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Field Editor */}
            <div>
              {editingField ? (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">แก้ไขฟิลด์</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="field-name">ชื่อฟิลด์</Label>
                      <Input
                        id="field-name"
                        value={editingField.name}
                        onChange={(e) =>
                          setEditingField({
                            ...editingField,
                            name: e.target.value,
                          })
                        }
                      />
                    </div>

                    <div>
                      <Label htmlFor="field-type">ประเภทฟิลด์</Label>
                      <Select
                        value={editingField.type}
                        onValueChange={(value: any) =>
                          setEditingField({
                            ...editingField,
                            type: value,
                          })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="text">ข้อความ</SelectItem>
                          <SelectItem value="number">ตัวเลข</SelectItem>
                          <SelectItem value="date">วันที่</SelectItem>
                          <SelectItem value="checkbox">ช่องติ๊ก</SelectItem>
                          <SelectItem value="signature">ลายเซ็น</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="field-x">ตำแหน่ง X</Label>
                        <Input
                          id="field-x"
                          type="number"
                          value={editingField.x}
                          onChange={(e) =>
                            setEditingField({
                              ...editingField,
                              x: Number.parseInt(e.target.value) || 0,
                            })
                          }
                        />
                      </div>
                      <div>
                        <Label htmlFor="field-y">ตำแหน่ง Y</Label>
                        <Input
                          id="field-y"
                          type="number"
                          value={editingField.y}
                          onChange={(e) =>
                            setEditingField({
                              ...editingField,
                              y: Number.parseInt(e.target.value) || 0,
                            })
                          }
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="field-width">ความกว้าง</Label>
                        <Input
                          id="field-width"
                          type="number"
                          value={editingField.width}
                          onChange={(e) =>
                            setEditingField({
                              ...editingField,
                              width: Number.parseInt(e.target.value) || 0,
                            })
                          }
                        />
                      </div>
                      <div>
                        <Label htmlFor="field-height">ความสูง</Label>
                        <Input
                          id="field-height"
                          type="number"
                          value={editingField.height}
                          onChange={(e) =>
                            setEditingField({
                              ...editingField,
                              height: Number.parseInt(e.target.value) || 0,
                            })
                          }
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="field-page">หน้า</Label>
                      <Input
                        id="field-page"
                        type="number"
                        value={editingField.page}
                        onChange={(e) =>
                          setEditingField({
                            ...editingField,
                            page: Number.parseInt(e.target.value) || 1,
                          })
                        }
                      />
                    </div>

                    <div className="flex items-center space-x-2">
                      <Switch
                        id="field-required"
                        checked={editingField.required}
                        onCheckedChange={(checked) =>
                          setEditingField({
                            ...editingField,
                            required: checked,
                          })
                        }
                      />
                      <Label htmlFor="field-required">ฟิลด์จำเป็น</Label>
                    </div>

                    <div className="flex gap-2">
                      <Button onClick={() => handleFieldUpdate(editingField)} className="flex-1">
                        บันทึก
                      </Button>
                      <Button variant="outline" onClick={() => setEditingField(null)} className="flex-1">
                        ยกเลิก
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ) : selectedField ? (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">รายละเอียดฟิลด์</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <Label>ชื่อฟิลด์</Label>
                      <p className="font-medium">{selectedField.name}</p>
                    </div>
                    <div>
                      <Label>ประเภท</Label>
                      <Badge className={getFieldTypeColor(selectedField.type)}>{selectedField.type}</Badge>
                    </div>
                    <div>
                      <Label>ตำแหน่งและขนาด</Label>
                      <p className="text-sm text-muted-foreground">
                        หน้า {selectedField.page} • ตำแหน่ง ({selectedField.x}, {selectedField.y}) • ขนาด{" "}
                        {selectedField.width}×{selectedField.height}
                      </p>
                    </div>
                    <div>
                      <Label>ความมั่นใจ</Label>
                      <p className="font-medium">{Math.round(selectedField.confidence * 100)}%</p>
                    </div>
                    <div>
                      <Label>สถานะ</Label>
                      <Badge variant={selectedField.required ? "destructive" : "secondary"}>
                        {selectedField.required ? "จำเป็น" : "ไม่จำเป็น"}
                      </Badge>
                    </div>
                    <Button onClick={() => setEditingField(selectedField)} className="w-full">
                      <Edit className="w-4 h-4 mr-2" />
                      แก้ไขฟิลด์
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <div className="text-center text-muted-foreground py-8">
                  <p>เลือกฟิลด์เพื่อดูรายละเอียดหรือแก้ไข</p>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
