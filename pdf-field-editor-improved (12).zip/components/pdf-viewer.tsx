"use client"

import type React from "react"
import { useState, useEffect, useRef, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { ZoomIn, ZoomOut, RotateCw } from "lucide-react"
import { PDFViewerFallback } from "./pdf-viewer-fallback"

interface PDFViewerProps {
  file: File | null
  fields: DetectedField[]
  selectedField: DetectedField | null
  onFieldSelect: (field: DetectedField) => void
  onFieldUpdate: (field: DetectedField) => void
  onFieldCreate: (field: Omit<DetectedField, "id">) => void
}

interface DetectedField {
  id: string
  name: string
  type: "text" | "number" | "date" | "checkbox" | "signature"
  x: number
  y: number
  width: number
  height: number
  page: number
  confidence: number
  required: boolean
}

export function PDFViewer({
  file,
  fields,
  selectedField,
  onFieldSelect,
  onFieldUpdate,
  onFieldCreate,
}: PDFViewerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const [pdfDoc, setPdfDoc] = useState<any>(null)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(0)
  const [zoom, setZoom] = useState(1)
  const [rotation, setRotation] = useState(0)
  const [isDrawing, setIsDrawing] = useState(false)
  const [pdfError, setPdfError] = useState<string | null>(null)
  const [drawingField, setDrawingField] = useState<{
    startX: number
    startY: number
    currentX: number
    currentY: number
  } | null>(null)

  const [pdfjsLib, setPdfjsLib] = useState<any>(null)

  // Load PDF.js dynamically with error handling
  useEffect(() => {
    const loadPdfJs = async () => {
      try {
        const pdfjsModule = await import("pdfjs-dist")
        pdfjsModule.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/4.0.379/pdf.worker.min.js`
        setPdfjsLib(pdfjsModule)
      } catch (error) {
        console.error("Error loading PDF.js:", error)
        setPdfError(error instanceof Error ? error.message : "Failed to load PDF.js")
      }
    }

    loadPdfJs()
  }, [])

  useEffect(() => {
    if (typeof window !== "undefined" && file && pdfjsLib) {
      loadPDFWithErrorHandling(file, pdfjsLib)
    }
  }, [file, pdfjsLib])

  const loadPDFWithErrorHandling = async (file: File, pdfjsLib: any) => {
    try {
      setPdfError(null)
      await loadPDF(file, pdfjsLib)
    } catch (error) {
      console.error("Error loading PDF:", error)
      setPdfError(error instanceof Error ? error.message : "ไม่สามารถโหลด PDF ได้")
    }
  }

  const loadPDF = async (file: File, pdfjsLib: any) => {
    try {
      const arrayBuffer = await file.arrayBuffer()
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise
      setPdfDoc(pdf)
      setTotalPages(pdf.numPages)
      setCurrentPage(1)
      setPdfError(null)
    } catch (error) {
      console.error("Error loading PDF document:", error)
      throw new Error("ไม่สามารถอ่านไฟล์ PDF ได้")
    }
  }

  // If there's a PDF error, show fallback
  if (pdfError) {
    return (
      <PDFViewerFallback
        file={file}
        fields={fields}
        selectedField={selectedField}
        onFieldSelect={onFieldSelect}
        onFieldUpdate={onFieldUpdate}
        onFieldCreate={onFieldCreate}
      />
    )
  }

  // Rest of the component remains the same...
  const renderPage = useCallback(async () => {
    if (!pdfDoc || !canvasRef.current) return

    try {
      const page = await pdfDoc.getPage(currentPage)
      const canvas = canvasRef.current
      const context = canvas.getContext("2d")

      const viewport = page.getViewport({
        scale: zoom,
        rotation: rotation,
      })

      canvas.height = viewport.height
      canvas.width = viewport.width

      // Clear canvas
      context.clearRect(0, 0, canvas.width, canvas.height)

      // Render PDF page
      await page.render({
        canvasContext: context,
        viewport: viewport,
      }).promise

      // Render fields on top
      renderFields(context, viewport)
    } catch (error) {
      console.error("Error rendering page:", error)
      setPdfError("ไม่สามารถแสดงหน้า PDF ได้")
    }
  }, [pdfDoc, currentPage, zoom, rotation, fields, selectedField])

  const renderFields = (context: CanvasRenderingContext2D, viewport: any) => {
    const pageFields = fields.filter((field) => field.page === currentPage)

    pageFields.forEach((field) => {
      const isSelected = selectedField?.id === field.id

      // Scale field coordinates
      const scaledX = field.x * zoom
      const scaledY = field.y * zoom
      const scaledWidth = field.width * zoom
      const scaledHeight = field.height * zoom

      // Draw field rectangle
      context.strokeStyle = isSelected ? "#3b82f6" : getFieldColor(field.type)
      context.lineWidth = isSelected ? 3 : 2
      context.setLineDash(isSelected ? [] : [5, 5])
      context.strokeRect(scaledX, scaledY, scaledWidth, scaledHeight)

      // Fill with semi-transparent color
      context.fillStyle = isSelected ? "rgba(59, 130, 246, 0.2)" : getFieldFillColor(field.type)
      context.fillRect(scaledX, scaledY, scaledWidth, scaledHeight)

      // Draw field label
      context.fillStyle = "#1f2937"
      context.font = `${12 * zoom}px sans-serif`
      context.fillText(field.name, scaledX, scaledY - 5)

      // Draw confidence score
      if (field.confidence < 1) {
        context.fillStyle = field.confidence > 0.8 ? "#059669" : "#dc2626"
        context.font = `${10 * zoom}px sans-serif`
        context.fillText(`${Math.round(field.confidence * 100)}%`, scaledX + scaledWidth - 30, scaledY - 5)
      }
    })

    // Draw current drawing field
    if (drawingField) {
      context.strokeStyle = "#8b5cf6"
      context.lineWidth = 2
      context.setLineDash([3, 3])
      const width = drawingField.currentX - drawingField.startX
      const height = drawingField.currentY - drawingField.startY
      context.strokeRect(drawingField.startX, drawingField.startY, width, height)
    }
  }

  const getFieldColor = (type: string) => {
    const colors = {
      text: "#3b82f6",
      number: "#10b981",
      date: "#8b5cf6",
      checkbox: "#f59e0b",
      signature: "#ef4444",
    }
    return colors[type as keyof typeof colors] || "#6b7280"
  }

  const getFieldFillColor = (type: string) => {
    const colors = {
      text: "rgba(59, 130, 246, 0.1)",
      number: "rgba(16, 185, 129, 0.1)",
      date: "rgba(139, 92, 246, 0.1)",
      checkbox: "rgba(245, 158, 11, 0.1)",
      signature: "rgba(239, 68, 68, 0.1)",
    }
    return colors[type as keyof typeof colors] || "rgba(107, 114, 128, 0.1)"
  }

  // Re-render when dependencies change
  useEffect(() => {
    renderPage()
  }, [renderPage])

  const handleCanvasMouseDown = (e: React.MouseEvent) => {
    if (!canvasRef.current) return

    const rect = canvasRef.current.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    // Check if clicking on existing field
    const clickedField = fields.find((field) => {
      if (field.page !== currentPage) return false

      const scaledX = field.x * zoom
      const scaledY = field.y * zoom
      const scaledWidth = field.width * zoom
      const scaledHeight = field.height * zoom

      return x >= scaledX && x <= scaledX + scaledWidth && y >= scaledY && y <= scaledY + scaledHeight
    })

    if (clickedField) {
      onFieldSelect(clickedField)
    } else {
      // Start drawing new field
      setIsDrawing(true)
      setDrawingField({
        startX: x,
        startY: y,
        currentX: x,
        currentY: y,
      })
    }
  }

  const handleCanvasMouseMove = (e: React.MouseEvent) => {
    if (!isDrawing || !drawingField || !canvasRef.current) return

    const rect = canvasRef.current.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    setDrawingField({
      ...drawingField,
      currentX: x,
      currentY: y,
    })

    renderPage()
  }

  const handleCanvasMouseUp = () => {
    if (!isDrawing || !drawingField) return

    const width = Math.abs(drawingField.currentX - drawingField.startX)
    const height = Math.abs(drawingField.currentY - drawingField.startY)

    // Only create field if it's big enough
    if (width > 20 && height > 10) {
      const newField: Omit<DetectedField, "id"> = {
        name: `ฟิลด์ใหม่ ${fields.length + 1}`,
        type: "text",
        x: Math.min(drawingField.startX, drawingField.currentX) / zoom,
        y: Math.min(drawingField.startY, drawingField.currentY) / zoom,
        width: width / zoom,
        height: height / zoom,
        page: currentPage,
        confidence: 1.0,
        required: false,
      }

      onFieldCreate(newField)
    }

    setIsDrawing(false)
    setDrawingField(null)
  }

  return (
    <div className="space-y-4">
      {/* PDF Controls */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>PDF Viewer</CardTitle>
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                disabled={currentPage <= 1}
              >
                ก่อนหน้า
              </Button>
              <span className="text-sm">
                หน้า {currentPage} จาก {totalPages}
              </span>
              <Button
                size="sm"
                variant="outline"
                onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                disabled={currentPage >= totalPages}
              >
                ถัดไป
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 mb-4">
            <div className="flex items-center gap-2">
              <Button size="sm" variant="outline" onClick={() => setZoom(Math.max(0.5, zoom - 0.1))}>
                <ZoomOut className="w-4 h-4" />
              </Button>
              <div className="w-32">
                <Slider
                  value={[zoom]}
                  onValueChange={([value]) => setZoom(value)}
                  min={0.5}
                  max={3}
                  step={0.1}
                  className="w-full"
                />
              </div>
              <Button size="sm" variant="outline" onClick={() => setZoom(Math.min(3, zoom + 0.1))}>
                <ZoomIn className="w-4 h-4" />
              </Button>
              <span className="text-sm">{Math.round(zoom * 100)}%</span>
            </div>

            <Button size="sm" variant="outline" onClick={() => setRotation((rotation + 90) % 360)}>
              <RotateCw className="w-4 h-4" />
            </Button>
          </div>

          {/* PDF Canvas */}
          <div
            ref={containerRef}
            className="border border-border rounded-lg overflow-auto max-h-[600px] bg-gray-50"
            style={{ cursor: isDrawing ? "crosshair" : "default" }}
          >
            {file && pdfDoc ? (
              <canvas
                ref={canvasRef}
                onMouseDown={handleCanvasMouseDown}
                onMouseMove={handleCanvasMouseMove}
                onMouseUp={handleCanvasMouseUp}
                className="block mx-auto"
              />
            ) : (
              <div className="p-8 text-center text-muted-foreground">
                <p>กำลังโหลด PDF...</p>
              </div>
            )}
          </div>

          <div className="mt-4 text-sm text-muted-foreground">
            <p>💡 เคล็ดลับ: คลิกและลากเพื่อสร้างฟิลด์ใหม่ หรือคลิกฟิลด์ที่มีอยู่เพื่อเลือก</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export { PDFViewer as default }
