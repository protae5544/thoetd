"use client"

import type React from "react"

import { useState, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Upload, Play, Pause, Square, Download, FileText, CheckCircle2, AlertCircle, Clock } from "lucide-react"

interface BatchJob {
  id: string
  file: File
  status: "pending" | "processing" | "completed" | "error" | "paused"
  progress: number
  result?: any
  error?: string
  startTime?: Date
  endTime?: Date
}

interface BatchProcessorProps {
  onJobComplete?: (job: BatchJob) => void
}

export function BatchProcessor({ onJobComplete }: BatchProcessorProps) {
  const [jobs, setJobs] = useState<BatchJob[]>([])
  const [isProcessing, setIsProcessing] = useState(false)
  const [isPaused, setIsPaused] = useState(false)
  const [currentJobIndex, setCurrentJobIndex] = useState(0)

  const handleFilesUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || [])
    const newJobs: BatchJob[] = files
      .filter((file) => file.type === "application/pdf")
      .map((file) => ({
        id: `job-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        file,
        status: "pending" as const,
        progress: 0,
      }))

    setJobs((prev) => [...prev, ...newJobs])
  }, [])

  const processNextJob = async () => {
    if (currentJobIndex >= jobs.length || isPaused) return

    const job = jobs[currentJobIndex]
    if (job.status !== "pending") {
      setCurrentJobIndex((prev) => prev + 1)
      return
    }

    // Update job status to processing
    setJobs((prev) =>
      prev.map((j) =>
        j.id === job.id ? { ...j, status: "processing" as const, startTime: new Date(), progress: 0 } : j,
      ),
    )

    try {
      // Simulate processing steps
      const steps = [
        { name: "อ่านไฟล์ PDF", duration: 1000, progress: 20 },
        { name: "OCR และแยกข้อความ", duration: 2000, progress: 50 },
        { name: "จำแนกประเภทเอกสาร", duration: 1500, progress: 70 },
        { name: "ตรวจจับฟิลด์ด้วย AI", duration: 2500, progress: 90 },
        { name: "สร้าง template", duration: 500, progress: 100 },
      ]

      for (const step of steps) {
        if (isPaused) {
          setJobs((prev) => prev.map((j) => (j.id === job.id ? { ...j, status: "paused" as const } : j)))
          return
        }

        await new Promise((resolve) => setTimeout(resolve, step.duration))

        setJobs((prev) => prev.map((j) => (j.id === job.id ? { ...j, progress: step.progress } : j)))
      }

      // Mock processing result
      const result = {
        documentType: "work-permit-change",
        fields: [
          {
            id: "field-1",
            name: "ชื่อผู้ยื่นคำขอ",
            type: "text",
            x: 150,
            y: 120,
            width: 200,
            height: 20,
            page: 1,
            confidence: 0.9,
            required: true,
          },
        ],
        confidence: 0.87,
        pages: 1,
      }

      setJobs((prev) =>
        prev.map((j) =>
          j.id === job.id
            ? {
                ...j,
                status: "completed" as const,
                progress: 100,
                result,
                endTime: new Date(),
              }
            : j,
        ),
      )

      onJobComplete?.(job)
    } catch (error) {
      setJobs((prev) =>
        prev.map((j) =>
          j.id === job.id
            ? {
                ...j,
                status: "error" as const,
                error: error instanceof Error ? error.message : "Unknown error",
                endTime: new Date(),
              }
            : j,
        ),
      )
    }

    setCurrentJobIndex((prev) => prev + 1)
  }

  const startBatchProcessing = async () => {
    setIsProcessing(true)
    setIsPaused(false)
    setCurrentJobIndex(0)

    while (currentJobIndex < jobs.length && !isPaused) {
      await processNextJob()
    }

    setIsProcessing(false)
  }

  const pauseProcessing = () => {
    setIsPaused(true)
  }

  const resumeProcessing = () => {
    setIsPaused(false)
    if (isProcessing) {
      processNextJob()
    }
  }

  const stopProcessing = () => {
    setIsProcessing(false)
    setIsPaused(false)
    setCurrentJobIndex(0)

    // Reset pending jobs
    setJobs((prev) =>
      prev.map((job) =>
        job.status === "processing" || job.status === "paused"
          ? { ...job, status: "pending" as const, progress: 0 }
          : job,
      ),
    )
  }

  const removeJob = (jobId: string) => {
    setJobs((prev) => prev.filter((job) => job.id !== jobId))
  }

  const downloadResults = () => {
    const completedJobs = jobs.filter((job) => job.status === "completed")
    const results = completedJobs.map((job) => ({
      filename: job.file.name,
      result: job.result,
    }))

    const blob = new Blob([JSON.stringify(results, null, 2)], {
      type: "application/json",
    })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = `batch-results-${new Date().toISOString().split("T")[0]}.json`
    link.click()
    URL.revokeObjectURL(url)
  }

  const getStatusIcon = (status: BatchJob["status"]) => {
    switch (status) {
      case "pending":
        return <Clock className="w-4 h-4 text-gray-500" />
      case "processing":
        return <div className="w-4 h-4 animate-pulse bg-blue-500 rounded-full" />
      case "completed":
        return <CheckCircle2 className="w-4 h-4 text-green-500" />
      case "error":
        return <AlertCircle className="w-4 h-4 text-red-500" />
      case "paused":
        return <Pause className="w-4 h-4 text-yellow-500" />
    }
  }

  const getStatusText = (status: BatchJob["status"]) => {
    switch (status) {
      case "pending":
        return "รอประมวลผล"
      case "processing":
        return "กำลังประมวลผล"
      case "completed":
        return "เสร็จสิ้น"
      case "error":
        return "เกิดข้อผิดพลาด"
      case "paused":
        return "หยุดชั่วคราว"
    }
  }

  const completedJobs = jobs.filter((job) => job.status === "completed").length
  const errorJobs = jobs.filter((job) => job.status === "error").length
  const totalJobs = jobs.length

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Batch Processing
            </CardTitle>
            <div className="flex gap-2">
              <input
                type="file"
                accept=".pdf"
                multiple
                onChange={handleFilesUpload}
                className="hidden"
                id="batch-upload"
              />
              <Button variant="outline" onClick={() => document.getElementById("batch-upload")?.click()}>
                <Upload className="w-4 h-4 mr-2" />
                เพิ่มไฟล์
              </Button>

              {!isProcessing ? (
                <Button onClick={startBatchProcessing} disabled={jobs.length === 0}>
                  <Play className="w-4 h-4 mr-2" />
                  เริ่มประมวลผล
                </Button>
              ) : (
                <div className="flex gap-2">
                  {!isPaused ? (
                    <Button variant="outline" onClick={pauseProcessing}>
                      <Pause className="w-4 h-4 mr-2" />
                      หยุดชั่วคราว
                    </Button>
                  ) : (
                    <Button variant="outline" onClick={resumeProcessing}>
                      <Play className="w-4 h-4 mr-2" />
                      ดำเนินการต่อ
                    </Button>
                  )}
                  <Button variant="destructive" onClick={stopProcessing}>
                    <Square className="w-4 h-4 mr-2" />
                    หยุด
                  </Button>
                </div>
              )}

              {completedJobs > 0 && (
                <Button variant="outline" onClick={downloadResults}>
                  <Download className="w-4 h-4 mr-2" />
                  ดาวน์โหลดผลลัพธ์
                </Button>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Statistics */}
          <div className="grid grid-cols-4 gap-4 mb-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{totalJobs}</div>
              <div className="text-sm text-muted-foreground">ไฟล์ทั้งหมด</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{completedJobs}</div>
              <div className="text-sm text-muted-foreground">เสร็จสิ้น</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">{errorJobs}</div>
              <div className="text-sm text-muted-foreground">ข้อผิดพลาด</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-600">{totalJobs - completedJobs - errorJobs}</div>
              <div className="text-sm text-muted-foreground">รอประมวลผล</div>
            </div>
          </div>

          {/* Overall Progress */}
          {isProcessing && (
            <div className="mb-6">
              <div className="flex justify-between text-sm mb-2">
                <span>ความคืบหน้าโดยรวม</span>
                <span>{Math.round((completedJobs / totalJobs) * 100)}%</span>
              </div>
              <Progress value={(completedJobs / totalJobs) * 100} />
            </div>
          )}

          {/* Jobs Table */}
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ไฟล์</TableHead>
                  <TableHead>สถานะ</TableHead>
                  <TableHead>ความคืบหน้า</TableHead>
                  <TableHead>เวลาประมวลผล</TableHead>
                  <TableHead>การจัดการ</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {jobs.map((job) => (
                  <TableRow key={job.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <FileText className="w-4 h-4" />
                        <span className="truncate max-w-[200px]">{job.file.name}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {getStatusIcon(job.status)}
                        <Badge
                          variant={
                            job.status === "completed"
                              ? "default"
                              : job.status === "error"
                                ? "destructive"
                                : job.status === "processing"
                                  ? "default"
                                  : "secondary"
                          }
                        >
                          {getStatusText(job.status)}
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="w-full max-w-[100px]">
                        <Progress value={job.progress} />
                        <div className="text-xs text-muted-foreground mt-1">{job.progress}%</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      {job.startTime && (
                        <div className="text-sm">
                          <div>เริ่ม: {job.startTime.toLocaleTimeString()}</div>
                          {job.endTime && <div>จบ: {job.endTime.toLocaleTimeString()}</div>}
                        </div>
                      )}
                    </TableCell>
                    <TableCell>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => removeJob(job.id)}
                        disabled={job.status === "processing"}
                      >
                        ลบ
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {jobs.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <Upload className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p>ยังไม่มีไฟล์ในคิว</p>
              <p className="text-sm">คลิก "เพิ่มไฟล์" เพื่อเริ่มต้น</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export { BatchProcessor as default }
