"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Plus, Edit, Trash2, Download, Upload, Copy, Star, StarOff } from "lucide-react"

interface FieldTemplate {
  id: string
  name: string
  type: "text" | "number" | "date" | "checkbox" | "signature"
  required: boolean
  format?: string
  validation?: {
    minLength?: number
    maxLength?: number
    pattern?: string
    min?: number
    max?: number
  }
  defaultValue?: string
}

interface DocumentTemplate {
  id: string
  name: string
  description: string
  documentType: string
  fields: FieldTemplate[]
  isDefault: boolean
  isStarred: boolean
  createdAt: Date
  updatedAt: Date
  usageCount: number
  tags: string[]
}

export function TemplateManager() {
  const [templates, setTemplates] = useState<DocumentTemplate[]>([])
  const [selectedTemplate, setSelectedTemplate] = useState<DocumentTemplate | null>(null)
  const [isEditing, setIsEditing] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState<string>("")

  // Load templates from localStorage
  useEffect(() => {
    const savedTemplates = localStorage.getItem("pdf-templates")
    if (savedTemplates) {
      setTemplates(JSON.parse(savedTemplates))
    } else {
      // Load default templates
      setTemplates(getDefaultTemplates())
    }
  }, [])

  // Save templates to localStorage
  useEffect(() => {
    localStorage.setItem("pdf-templates", JSON.stringify(templates))
  }, [templates])

  const getDefaultTemplates = (): DocumentTemplate[] => [
    {
      id: "wp-44",
      name: "คำขอเปลี่ยนรายการใบอนุญาตทำงาน (บต.44)",
      description: "Template สำหรับฟอร์มคำขอเปลี่ยนรายการในใบอนุญาตทำงาน",
      documentType: "work-permit-change",
      isDefault: true,
      isStarred: true,
      createdAt: new Date(),
      updatedAt: new Date(),
      usageCount: 15,
      tags: ["work-permit", "government", "labor"],
      fields: [
        {
          id: "wp-name",
          name: "ชื่อผู้ยื่นคำขอ",
          type: "text",
          required: true,
          validation: { minLength: 2, maxLength: 100 },
        },
        {
          id: "wp-nationality",
          name: "สัญชาติ",
          type: "text",
          required: true,
        },
        {
          id: "wp-permit-number",
          name: "เลขที่ใบอนุญาตทำงาน",
          type: "text",
          required: true,
          validation: { pattern: "^[A-Z0-9-]+$" },
        },
        {
          id: "wp-issue-date",
          name: "วันที่ออกใบอนุญาต",
          type: "date",
          required: true,
          format: "DD/MM/YYYY",
        },
      ],
    },
    {
      id: "emp-cert",
      name: "หนังสือรับรองการจ้าง (บต.46)",
      description: "Template สำหรับฟอร์มหนังสือรับรองการจ้าง",
      documentType: "employment-cert",
      isDefault: true,
      isStarred: false,
      createdAt: new Date(),
      updatedAt: new Date(),
      usageCount: 8,
      tags: ["employment", "certification", "labor"],
      fields: [
        {
          id: "emp-employer",
          name: "ชื่อนายจ้าง",
          type: "text",
          required: true,
        },
        {
          id: "emp-address",
          name: "ที่อยู่",
          type: "text",
          required: true,
        },
        {
          id: "emp-business-type",
          name: "ประเภทกิจการ",
          type: "text",
          required: true,
        },
      ],
    },
  ]

  const handleCreateTemplate = () => {
    const newTemplate: DocumentTemplate = {
      id: `template-${Date.now()}`,
      name: "Template ใหม่",
      description: "",
      documentType: "custom",
      fields: [],
      isDefault: false,
      isStarred: false,
      createdAt: new Date(),
      updatedAt: new Date(),
      usageCount: 0,
      tags: [],
    }
    setSelectedTemplate(newTemplate)
    setIsEditing(true)
  }

  const handleSaveTemplate = (template: DocumentTemplate) => {
    const updatedTemplate = {
      ...template,
      updatedAt: new Date(),
    }

    if (templates.find((t) => t.id === template.id)) {
      setTemplates((prev) => prev.map((t) => (t.id === template.id ? updatedTemplate : t)))
    } else {
      setTemplates((prev) => [...prev, updatedTemplate])
    }

    setIsEditing(false)
    setSelectedTemplate(null)
  }

  const handleDeleteTemplate = (templateId: string) => {
    setTemplates((prev) => prev.filter((t) => t.id !== templateId))
    if (selectedTemplate?.id === templateId) {
      setSelectedTemplate(null)
    }
  }

  const handleToggleStar = (templateId: string) => {
    setTemplates((prev) => prev.map((t) => (t.id === templateId ? { ...t, isStarred: !t.isStarred } : t)))
  }

  const handleDuplicateTemplate = (template: DocumentTemplate) => {
    const duplicated: DocumentTemplate = {
      ...template,
      id: `template-${Date.now()}`,
      name: `${template.name} (สำเนา)`,
      isDefault: false,
      createdAt: new Date(),
      updatedAt: new Date(),
      usageCount: 0,
    }
    setTemplates((prev) => [...prev, duplicated])
  }

  const handleExportTemplate = (template: DocumentTemplate) => {
    const exportData = {
      ...template,
      exportedAt: new Date().toISOString(),
      version: "1.0.0",
    }

    const blob = new Blob([JSON.stringify(exportData, null, 2)], {
      type: "application/json",
    })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = `${template.name.replace(/[^a-zA-Z0-9]/g, "_")}.json`
    link.click()
    URL.revokeObjectURL(url)
  }

  const handleImportTemplate = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const imported = JSON.parse(e.target?.result as string)
        const newTemplate: DocumentTemplate = {
          ...imported,
          id: `template-${Date.now()}`,
          createdAt: new Date(),
          updatedAt: new Date(),
          usageCount: 0,
          isDefault: false,
        }
        setTemplates((prev) => [...prev, newTemplate])
      } catch (error) {
        console.error("Error importing template:", error)
      }
    }
    reader.readAsText(file)
  }

  const filteredTemplates = templates.filter((template) => {
    const matchesSearch =
      template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      template.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesType = !filterType || template.documentType === filterType
    return matchesSearch && matchesType
  })

  const documentTypes = Array.from(new Set(templates.map((t) => t.documentType)))

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>จัดการ Template</CardTitle>
            <div className="flex gap-2">
              <input
                type="file"
                accept=".json"
                onChange={handleImportTemplate}
                className="hidden"
                id="import-template"
              />
              <Button variant="outline" onClick={() => document.getElementById("import-template")?.click()}>
                <Upload className="w-4 h-4 mr-2" />
                Import
              </Button>
              <Button onClick={handleCreateTemplate}>
                <Plus className="w-4 h-4 mr-2" />
                สร้าง Template
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Search and Filter */}
          <div className="flex gap-4 mb-6">
            <div className="flex-1">
              <Input
                placeholder="ค้นหา template..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <select
              className="px-3 py-2 border border-border rounded-md"
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
            >
              <option value="">ทุกประเภท</option>
              {documentTypes.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
          </div>

          {/* Templates Table */}
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Template</TableHead>
                  <TableHead>ประเภท</TableHead>
                  <TableHead>ฟิลด์</TableHead>
                  <TableHead>การใช้งาน</TableHead>
                  <TableHead>วันที่อัปเดต</TableHead>
                  <TableHead>การจัดการ</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTemplates.map((template) => (
                  <TableRow key={template.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button size="sm" variant="ghost" onClick={() => handleToggleStar(template.id)}>
                          {template.isStarred ? (
                            <Star className="w-4 h-4 text-yellow-500 fill-current" />
                          ) : (
                            <StarOff className="w-4 h-4 text-gray-400" />
                          )}
                        </Button>
                        <div>
                          <div className="font-medium">{template.name}</div>
                          <div className="text-sm text-muted-foreground">{template.description}</div>
                          <div className="flex gap-1 mt-1">
                            {template.isDefault && (
                              <Badge variant="secondary" className="text-xs">
                                Default
                              </Badge>
                            )}
                            {template.tags.map((tag) => (
                              <Badge key={tag} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{template.documentType}</Badge>
                    </TableCell>
                    <TableCell>{template.fields.length}</TableCell>
                    <TableCell>{template.usageCount}</TableCell>
                    <TableCell>{template.updatedAt.toLocaleDateString("th")}</TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            setSelectedTemplate(template)
                            setIsEditing(true)
                          }}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => handleDuplicateTemplate(template)}>
                          <Copy className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => handleExportTemplate(template)}>
                          <Download className="w-4 h-4" />
                        </Button>
                        {!template.isDefault && (
                          <Button size="sm" variant="ghost" onClick={() => handleDeleteTemplate(template.id)}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {filteredTemplates.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <p>ไม่พบ template ที่ตรงกับเงื่อนไข</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Template Editor Dialog */}
      <Dialog open={isEditing} onOpenChange={setIsEditing}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{selectedTemplate ? "แก้ไข Template" : "สร้าง Template ใหม่"}</DialogTitle>
          </DialogHeader>

          {selectedTemplate && (
            <TemplateEditor
              template={selectedTemplate}
              onSave={handleSaveTemplate}
              onCancel={() => {
                setIsEditing(false)
                setSelectedTemplate(null)
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

// Template Editor Component
function TemplateEditor({
  template,
  onSave,
  onCancel,
}: {
  template: DocumentTemplate
  onSave: (template: DocumentTemplate) => void
  onCancel: () => void
}) {
  const [editingTemplate, setEditingTemplate] = useState<DocumentTemplate>(template)

  const handleAddField = () => {
    const newField: FieldTemplate = {
      id: `field-${Date.now()}`,
      name: "ฟิลด์ใหม่",
      type: "text",
      required: false,
    }
    setEditingTemplate((prev) => ({
      ...prev,
      fields: [...prev.fields, newField],
    }))
  }

  const handleUpdateField = (fieldId: string, updates: Partial<FieldTemplate>) => {
    setEditingTemplate((prev) => ({
      ...prev,
      fields: prev.fields.map((field) => (field.id === fieldId ? { ...field, ...updates } : field)),
    }))
  }

  const handleRemoveField = (fieldId: string) => {
    setEditingTemplate((prev) => ({
      ...prev,
      fields: prev.fields.filter((field) => field.id !== fieldId),
    }))
  }

  return (
    <div className="space-y-6">
      {/* Template Info */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="template-name">ชื่อ Template</Label>
          <Input
            id="template-name"
            value={editingTemplate.name}
            onChange={(e) => setEditingTemplate((prev) => ({ ...prev, name: e.target.value }))}
          />
        </div>
        <div>
          <Label htmlFor="template-type">ประเภทเอกสาร</Label>
          <Input
            id="template-type"
            value={editingTemplate.documentType}
            onChange={(e) => setEditingTemplate((prev) => ({ ...prev, documentType: e.target.value }))}
          />
        </div>
      </div>

      <div>
        <Label htmlFor="template-description">คำอธิบาย</Label>
        <Textarea
          id="template-description"
          value={editingTemplate.description}
          onChange={(e) => setEditingTemplate((prev) => ({ ...prev, description: e.target.value }))}
        />
      </div>

      <div>
        <Label htmlFor="template-tags">Tags (คั่นด้วย comma)</Label>
        <Input
          id="template-tags"
          value={editingTemplate.tags.join(", ")}
          onChange={(e) =>
            setEditingTemplate((prev) => ({
              ...prev,
              tags: e.target.value
                .split(",")
                .map((tag) => tag.trim())
                .filter(Boolean),
            }))
          }
        />
      </div>

      {/* Fields */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <Label>ฟิลด์</Label>
          <Button onClick={handleAddField}>
            <Plus className="w-4 h-4 mr-2" />
            เพิ่มฟิลด์
          </Button>
        </div>

        <div className="space-y-4">
          {editingTemplate.fields.map((field) => (
            <Card key={field.id}>
              <CardContent className="pt-4">
                <div className="grid grid-cols-12 gap-4 items-end">
                  <div className="col-span-3">
                    <Label>ชื่อฟิลด์</Label>
                    <Input value={field.name} onChange={(e) => handleUpdateField(field.id, { name: e.target.value })} />
                  </div>
                  <div className="col-span-2">
                    <Label>ประเภท</Label>
                    <select
                      className="w-full px-3 py-2 border border-border rounded-md"
                      value={field.type}
                      onChange={(e) => handleUpdateField(field.id, { type: e.target.value as any })}
                    >
                      <option value="text">ข้อความ</option>
                      <option value="number">ตัวเลข</option>
                      <option value="date">วันที่</option>
                      <option value="checkbox">ช่องติ๊ก</option>
                      <option value="signature">ลายเซ็น</option>
                    </select>
                  </div>
                  <div className="col-span-2">
                    <Label>รูปแบบ</Label>
                    <Input
                      value={field.format || ""}
                      onChange={(e) => handleUpdateField(field.id, { format: e.target.value })}
                      placeholder="เช่น DD/MM/YYYY"
                    />
                  </div>
                  <div className="col-span-3">
                    <Label>ค่าเริ่มต้น</Label>
                    <Input
                      value={field.defaultValue || ""}
                      onChange={(e) => handleUpdateField(field.id, { defaultValue: e.target.value })}
                    />
                  </div>
                  <div className="col-span-1">
                    <Label>จำเป็น</Label>
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={field.required}
                        onChange={(e) => handleUpdateField(field.id, { required: e.target.checked })}
                      />
                    </div>
                  </div>
                  <div className="col-span-1">
                    <Button size="sm" variant="ghost" onClick={() => handleRemoveField(field.id)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Actions */}
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={onCancel}>
          ยกเลิก
        </Button>
        <Button onClick={() => onSave(editingTemplate)}>บันทึก</Button>
      </div>
    </div>
  )
}

// At the end of the file, make sure we have a default export
export { TemplateManager as default }
