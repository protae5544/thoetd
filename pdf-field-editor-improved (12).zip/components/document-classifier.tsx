"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { FileText, CheckCircle, AlertCircle } from "lucide-react"

interface ProcessedDocument {
  id: string
  name: string
  type: string
  originalFile: File
  pages: number
  status: "pending" | "processing" | "detected" | "confirmed" | "completed"
  fields: any[]
  confidence: number
}

interface DocumentClassifierProps {
  documents: ProcessedDocument[]
}

export function DocumentClassifier({ documents }: DocumentClassifierProps) {
  const getTypeDisplayName = (type: string) => {
    const typeMap: Record<string, string> = {
      "work-permit-change": "คำขอเปลี่ยนรายการในใบอนุญาตทำงาน (บต.44)",
      "employment-cert": "หนังสือรับรองการจ้าง (บต.46)",
      "power-of-attorney": "หนังสือมอบอำนาจ",
      "employment-contract": "สัญญาจ้างงาน",
      unknown: "ไม่สามารถระบุประเภทได้",
    }
    return typeMap[type] || type
  }

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.8) return "text-green-600"
    if (confidence >= 0.6) return "text-yellow-600"
    return "text-red-600"
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            การจำแนกประเภทเอกสาร
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            {documents.map((doc) => (
              <div key={doc.id} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <FileText className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">{doc.name}</h3>
                      <p className="text-sm text-muted-foreground">{getTypeDisplayName(doc.type)}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {doc.confidence > 0.8 ? (
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    ) : (
                      <AlertCircle className="w-5 h-5 text-yellow-600" />
                    )}
                    <Badge variant={doc.confidence > 0.8 ? "default" : "secondary"}>
                      {Math.round(doc.confidence * 100)}% มั่นใจ
                    </Badge>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>ความแม่นยำในการจำแนก</span>
                    <span className={getConfidenceColor(doc.confidence)}>{Math.round(doc.confidence * 100)}%</span>
                  </div>
                  <Progress value={doc.confidence * 100} className="h-2" />
                </div>

                {doc.type === "unknown" && (
                  <div className="mt-3 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <p className="text-sm text-yellow-800">
                      ⚠️ ไม่สามารถจำแนกประเภทเอกสารได้อย่างแม่นยำ กรุณาตรวจสอบและแก้ไขด้วยตนเอง
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>สถิติการจำแนก</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{documents.length}</div>
              <div className="text-sm text-muted-foreground">เอกสารทั้งหมด</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {documents.filter((d) => d.confidence > 0.8).length}
              </div>
              <div className="text-sm text-muted-foreground">จำแนกได้แม่นยำ</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-600">
                {documents.filter((d) => d.confidence <= 0.8 && d.confidence > 0.5).length}
              </div>
              <div className="text-sm text-muted-foreground">ต้องตรวจสอบ</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">
                {documents.filter((d) => d.confidence <= 0.5).length}
              </div>
              <div className="text-sm text-muted-foreground">ไม่สามารถจำแนกได้</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
