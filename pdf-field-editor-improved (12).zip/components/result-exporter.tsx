"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Download, FileJson, FileSpreadsheet, CheckCircle } from "lucide-react"

interface ProcessedDocument {
  id: string
  name: string
  type: string
  status: string
  fields: any[]
  confidence: number
}

interface ResultExporterProps {
  documents: ProcessedDocument[]
  onExport: (document: ProcessedDocument) => void
}

export function ResultExporter({ documents, onExport }: ResultExporterProps) {
  const exportAll = async () => {
    for (const doc of documents) {
      if (doc.status === "confirmed") {
        await onExport(doc)
      }
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Download className="w-5 h-5" />
              ส่งออกผลลัพธ์
            </CardTitle>
            <Button onClick={exportAll} disabled={documents.length === 0}>
              <Download className="w-4 h-4 mr-2" />
              ส่งออกทั้งหมด
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {documents.map((doc) => (
              <div key={doc.id} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h3 className="font-medium">{doc.name}</h3>
                    <p className="text-sm text-muted-foreground">
                      {doc.fields.length} ฟิลด์ • ความมั่นใจ {Math.round(doc.confidence * 100)}%
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={doc.status === "completed" ? "default" : "secondary"}>
                      {doc.status === "completed" ? "ส่งออกแล้ว" : "พร้อมส่งออก"}
                    </Badge>
                    {doc.status === "completed" && <CheckCircle className="w-5 h-5 text-green-600" />}
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => onExport(doc)}
                    disabled={doc.status === "completed"}
                  >
                    <FileJson className="w-4 h-4 mr-2" />
                    JSON Template
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => onExport(doc)}
                    disabled={doc.status === "completed"}
                  >
                    <FileSpreadsheet className="w-4 h-4 mr-2" />
                    CSV Template
                  </Button>
                </div>

                {doc.status === "completed" && (
                  <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="text-sm text-green-800">✅ ส่งออกเรียบร้อยแล้ว - ไฟล์ template JSON และ CSV พร้อมใช้งาน</p>
                  </div>
                )}
              </div>
            ))}

            {documents.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                <Download className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p>ไม่มีเอกสารที่พร้อมส่งออก</p>
                <p className="text-sm">กรุณายืนยันเอกสารก่อนส่งออก</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>รูปแบบไฟล์ที่ส่งออก</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 border rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <FileJson className="w-5 h-5 text-blue-600" />
                <h3 className="font-medium">JSON Template</h3>
              </div>
              <p className="text-sm text-muted-foreground mb-3">ไฟล์ JSON ที่มีข้อมูลฟิลด์ทั้งหมด รวมถึงตำแหน่ง ประเภท และคุณสมบัติ</p>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• ข้อมูลฟิลด์ครบถ้วน</li>
                <li>• ตำแหน่งและขนาดแม่นยำ</li>
                <li>• Metadata และ confidence score</li>
              </ul>
            </div>

            <div className="p-4 border rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <FileSpreadsheet className="w-5 h-5 text-green-600" />
                <h3 className="font-medium">CSV Template</h3>
              </div>
              <p className="text-sm text-muted-foreground mb-3">ไฟล์ CSV สำหรับกรอกข้อมูลจริง พร้อม header ของฟิลด์ทั้งหมด</p>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• Header ชื่อฟิลด์</li>
                <li>• แถวว่างสำหรับกรอกข้อมูล</li>
                <li>• รองรับการ import ข้อมูลจำนวนมาก</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
