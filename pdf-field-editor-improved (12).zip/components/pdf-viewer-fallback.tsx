"use client"
import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Upload, FileText, AlertCircle } from "lucide-react"

interface PDFViewerFallbackProps {
  file: File | null
  fields: DetectedField[]
  selectedField: DetectedField | null
  onFieldSelect: (field: DetectedField) => void
  onFieldUpdate: (field: DetectedField) => void
  onFieldCreate: (field: Omit<DetectedField, "id">) => void
}

interface DetectedField {
  id: string
  name: string
  type: "text" | "number" | "date" | "checkbox" | "signature"
  x: number
  y: number
  width: number
  height: number
  page: number
  confidence: number
  required: boolean
}

export function PDFViewerFallback({
  file,
  fields,
  selectedField,
  onFieldSelect,
  onFieldUpdate,
  onFieldCreate,
}: PDFViewerFallbackProps) {
  const [showFields, setShowFields] = useState(true)

  const getFieldTypeColor = (type: string) => {
    const colors = {
      text: "bg-blue-100 text-blue-800 border-blue-200",
      number: "bg-green-100 text-green-800 border-green-200",
      date: "bg-purple-100 text-purple-800 border-purple-200",
      checkbox: "bg-orange-100 text-orange-800 border-orange-200",
      signature: "bg-red-100 text-red-800 border-red-200",
    }
    return colors[type as keyof typeof colors] || "bg-gray-100 text-gray-800 border-gray-200"
  }

  const getFieldTypeName = (type: string) => {
    const names = {
      text: "ข้อความ",
      number: "ตัวเลข",
      date: "วันที่",
      checkbox: "ช่องติ๊ก",
      signature: "ลายเซ็น",
    }
    return names[type as keyof typeof names] || type
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            PDF Viewer (Fallback Mode)
          </CardTitle>
        </CardHeader>
        <CardContent>
          {file ? (
            <div className="space-y-4">
              {/* PDF Info */}
              <div className="p-4 bg-muted rounded-lg">
                <div className="flex items-center gap-3">
                  <FileText className="w-8 h-8 text-blue-600" />
                  <div>
                    <h3 className="font-medium">{file.name}</h3>
                    <p className="text-sm text-muted-foreground">ขนาด: {(file.size / 1024 / 1024).toFixed(2)} MB</p>
                  </div>
                </div>
              </div>

              {/* PDF.js Loading Error Notice */}
              <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <div className="flex items-center gap-2 text-yellow-800 mb-2">
                  <AlertCircle className="w-5 h-5" />
                  <span className="font-medium">PDF Viewer ไม่สามารถโหลดได้</span>
                </div>
                <p className="text-yellow-700 text-sm mb-3">เกิดปัญหาในการโหลด PDF.js library กำลังใช้โหมด fallback แทน</p>
                <p className="text-yellow-700 text-sm">💡 คุณยังสามารถดูและจัดการฟิลด์ที่ตรวจพบได้ด้านล่าง</p>
              </div>

              {/* Fields Management */}
              {fields.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-medium">ฟิลด์ที่ตรวจพบ ({fields.length})</h3>
                    <Button size="sm" variant="outline" onClick={() => setShowFields(!showFields)}>
                      {showFields ? "ซ่อน" : "แสดง"}ฟิลด์
                    </Button>
                  </div>

                  {showFields && (
                    <div className="grid gap-3">
                      {fields.map((field) => (
                        <div
                          key={field.id}
                          className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                            selectedField?.id === field.id
                              ? "border-primary bg-primary/5"
                              : "border-border hover:bg-muted/50"
                          }`}
                          onClick={() => onFieldSelect(field)}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <span className={`px-2 py-1 text-xs rounded border ${getFieldTypeColor(field.type)}`}>
                                {getFieldTypeName(field.type)}
                              </span>
                              <span className="font-medium">{field.name}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              {field.required && (
                                <span className="px-2 py-1 text-xs bg-red-100 text-red-800 rounded border border-red-200">
                                  จำเป็น
                                </span>
                              )}
                              <span className="text-sm text-muted-foreground">
                                {Math.round(field.confidence * 100)}%
                              </span>
                            </div>
                          </div>
                          <div className="text-xs text-muted-foreground">
                            หน้า {field.page} • ตำแหน่ง ({field.x}, {field.y}) • ขนาด {field.width}×{field.height}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Add Field Button */}
              <Button
                onClick={() => {
                  const newField: Omit<DetectedField, "id"> = {
                    name: `ฟิลด์ใหม่ ${fields.length + 1}`,
                    type: "text",
                    x: 100,
                    y: 100,
                    width: 150,
                    height: 20,
                    page: 1,
                    confidence: 1.0,
                    required: false,
                  }
                  onFieldCreate(newField)
                }}
                className="w-full"
                variant="outline"
              >
                เพิ่มฟิลด์ใหม่
              </Button>
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Upload className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>เลือกไฟล์ PDF เพื่อดูตัวอย่าง</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
