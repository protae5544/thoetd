# PDF Field Editor - Advanced

ระบบประมวลผลเอกสาร PDF อัตโนมัติด้วย AI สำหรับการตรวจจับและจัดการฟิลด์ในเอกสารราชการไทย

## ✨ ฟีเจอร์หลัก

- 🤖 **AI-Powered Field Detection** - ตรวจจับฟิลด์อัตโนมัติด้วย AI
- 📄 **Document Classification** - จำแนกประเภทเอกสารอัตโนมัติ
- 🔍 **OCR Integration** - แยกข้อความจากเอกสาร PDF
- ✏️ **Visual Field Editor** - แก้ไขฟิลด์แบบ visual
- 📊 **Template Export** - ส่งออก JSON และ CSV template
- 🌙 **Dark Mode Support** - รองรับโหมดมืด
- 📱 **Responsive Design** - ใช้งานได้ทุกอุปกรณ์

## 🚀 การติดตั้ง

1. **Clone repository**
\`\`\`bash
git clone <repository-url>
cd pdf-field-editor-advanced
\`\`\`

2. **ติดตั้ง dependencies**
\`\`\`bash
npm install
\`\`\`

3. **ตั้งค่า environment variables**
\`\`\`bash
cp .env.example .env.local
# แก้ไขไฟล์ .env.local ใส่ API keys
\`\`\`

4. **รันโปรเจค**
\`\`\`bash
npm run dev
\`\`\`

## 🔧 การตั้งค่า API Keys

### OpenAI API
1. ไปที่ [OpenAI Platform](https://platform.openai.com/)
2. สร้าง API key
3. ใส่ใน `NEXT_PUBLIC_OPENAI_API_KEY`

### Google Vision API (สำหรับ OCR)
1. ไปที่ [Google Cloud Console](https://console.cloud.google.com/)
2. เปิดใช้งาน Vision API
3. สร้าง Service Account และดาวน์โหลด JSON key
4. ใส่ข้อมูลใน environment variables

## 📋 การใช้งาน

1. **อัปโหลดเอกสาร** - เลือกไฟล์ PDF ที่ต้องการประมวลผล
2. **รอการจำแนก** - ระบบจะจำแนกประเภทเอกสารอัตโนมัติ
3. **ตรวจสอบฟิลด์** - ดูฟิลด์ที่ AI ตรวจจับได้
4. **แก้ไข/ยืนยัน** - แก้ไขฟิลด์ตามต้องการแล้วยืนยัน
5. **ส่งออกผลลัพธ์** - ดาวน์โหลด JSON และ CSV template

## 🏗️ สถาปัตยกรรม

\`\`\`
├── app/                    # Next.js App Router
├── components/            # React Components
│   ├── ui/               # UI Components (shadcn/ui)
│   ├── document-classifier.tsx
│   ├── field-detector.tsx
│   ├── field-editor.tsx
│   └── result-exporter.tsx
├── lib/                   # Utilities
│   ├── pdf-processor.ts   # PDF Processing
│   ├── ai-integration.ts  # AI API Integration
│   └── template-generator.ts # Template Generation
└── scripts/              # Setup Scripts
\`\`\`

## 🔌 API Integration

### PDF Processing API
\`\`\`typescript
POST /api/process-pdf
Content-Type: multipart/form-data

// Response
{
  "documentType": "work-permit-change",
  "confidence": 0.92,
  "fields": [...],
  "ocrText": "...",
  "pages": 3
}
\`\`\`

## 📦 Dependencies

- **Next.js 14** - React Framework
- **TypeScript** - Type Safety
- **Tailwind CSS** - Styling
- **shadcn/ui** - UI Components
- **Radix UI** - Headless Components
- **Lucide React** - Icons

## 🚀 Deployment

### Vercel (แนะนำ)
\`\`\`bash
npm run build
vercel --prod
\`\`\`

### Docker
\`\`\`bash
docker build -t pdf-field-editor .
docker run -p 3000:3000 pdf-field-editor
\`\`\`

## 🤝 การพัฒนาต่อ

1. **เพิ่ม OCR จริง** - เชื่อมต่อ Tesseract.js หรือ Google Vision
2. **เพิ่ม AI จริง** - เชื่อมต่อ OpenAI หรือ Claude API
3. **เพิ่ม Database** - เก็บข้อมูลเอกสารและ template
4. **เพิ่ม Authentication** - ระบบล็อกอิน/สมัครสมาชิก
5. **เพิ่ม Batch Processing** - ประมวลผลหลายไฟล์พร้อมกัน

## 📄 License

MIT License - ดูรายละเอียดใน LICENSE file
