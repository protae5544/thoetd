"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Upload, CheckCircle, AlertCircle, Loader2, ExternalLink, TestTube, Key, Eye, Zap } from "lucide-react"

export default function APITestPage() {
  const [file, setFile] = useState<File | null>(null)
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)
  const [testType, setTestType] = useState<
    | "upload"
    | "enhanced"
    | "health"
    | "docs"
    | "test"
    | "openai"
    | "google-vision"
    | "opentyphoon"
    | "huggingface"
    | "tesseract"
  >("upload")

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0]
    if (selectedFile && selectedFile.type === "application/pdf") {
      setFile(selectedFile)
      setError(null)
    } else {
      setError("กรุณาเลือกไฟล์ PDF")
      setFile(null)
    }
  }

  const testPDFProcessing = async () => {
    if (!file) {
      setError("กรุณาเลือกไฟล์ก่อน")
      return
    }

    setLoading(true)
    setError(null)
    setResult(null)
    setTestType("upload")

    try {
      const formData = new FormData()
      formData.append("file", file)

      const response = await fetch("/api/process-pdf", {
        method: "POST",
        body: formData,
      })

      const data = await response.json()

      if (response.ok && data.success) {
        setResult(data)
      } else {
        setError(data.error || `HTTP ${response.status}: ${response.statusText}`)
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "เกิดข้อผิดพลาดในการเชื่อมต่อ")
    } finally {
      setLoading(false)
    }
  }

  const testEnhancedPDFProcessing = async () => {
    if (!file) {
      setError("กรุณาเลือกไฟล์ก่อน")
      return
    }

    setLoading(true)
    setError(null)
    setResult(null)
    setTestType("enhanced")

    try {
      const formData = new FormData()
      formData.append("file", file)

      const response = await fetch("/api/process-pdf-enhanced", {
        method: "POST",
        body: formData,
      })

      const data = await response.json()

      if (response.ok && data.success) {
        setResult(data)
      } else {
        setError(data.error || `HTTP ${response.status}: ${response.statusText}`)
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "เกิดข้อผิดพลาดในการเชื่อมต่อ")
    } finally {
      setLoading(false)
    }
  }

  const testHealthCheck = async () => {
    setLoading(true)
    setError(null)
    setResult(null)
    setTestType("health")

    try {
      const response = await fetch("/api/health")
      const data = await response.json()

      if (response.ok) {
        setResult(data)
      } else {
        setError(`HTTP ${response.status}: ${response.statusText}`)
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "การตรวจสอบสถานะล้มเหลว")
    } finally {
      setLoading(false)
    }
  }

  const testAPIDocumentation = async () => {
    setLoading(true)
    setError(null)
    setResult(null)
    setTestType("docs")

    try {
      const response = await fetch("/api/process-pdf-enhanced", {
        method: "GET",
      })
      const data = await response.json()

      if (response.ok) {
        setResult(data)
      } else {
        setError(`HTTP ${response.status}: ${response.statusText}`)
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "ไม่สามารถโหลดเอกสารได้")
    } finally {
      setLoading(false)
    }
  }

  const testBasicAPI = async () => {
    setLoading(true)
    setError(null)
    setResult(null)
    setTestType("test")

    try {
      const response = await fetch("/api/test")
      const data = await response.json()

      if (response.ok) {
        setResult(data)
      } else {
        setError(`HTTP ${response.status}: ${response.statusText}`)
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "การทดสอบ API พื้นฐานล้มเหลว")
    } finally {
      setLoading(false)
    }
  }

  const testOpenAI = async () => {
    setLoading(true)
    setError(null)
    setResult(null)
    setTestType("openai")

    try {
      const response = await fetch("/api/test-openai")
      const data = await response.json()

      if (response.ok) {
        setResult(data)
      } else {
        setError(`HTTP ${response.status}: ${response.statusText}`)
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "การทดสอบ OpenAI API ล้มเหลว")
    } finally {
      setLoading(false)
    }
  }

  const testGoogleVision = async () => {
    setLoading(true)
    setError(null)
    setResult(null)
    setTestType("google-vision")

    try {
      const response = await fetch("/api/test-google-vision")
      const data = await response.json()

      if (response.ok) {
        setResult(data)
      } else {
        setError(`HTTP ${response.status}: ${response.statusText}`)
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "การทดสอบ Google Vision API ล้มเหลว")
    } finally {
      setLoading(false)
    }
  }

  const testOpenTyphoon = async () => {
    setLoading(true)
    setError(null)
    setResult(null)
    setTestType("opentyphoon")

    try {
      const response = await fetch("/api/test-opentyphoon")
      const data = await response.json()

      if (response.ok) {
        setResult(data)
      } else {
        setError(`HTTP ${response.status}: ${response.statusText}`)
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "การทดสอบ OpenTyphoon API ล้มเหลว")
    } finally {
      setLoading(false)
    }
  }

  const testHuggingFace = async () => {
    setLoading(true)
    setError(null)
    setResult(null)
    setTestType("huggingface")

    try {
      const response = await fetch("/api/test-huggingface")
      const data = await response.json()

      if (response.ok) {
        setResult(data)
      } else {
        setError(`HTTP ${response.status}: ${response.statusText}`)
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "การทดสอบ Hugging Face Space ล้มเหลว")
    } finally {
      setLoading(false)
    }
  }

  const testTesseract = async () => {
    setLoading(true)
    setError(null)
    setResult(null)
    setTestType("tesseract")

    try {
      const response = await fetch("/api/test-tesseract")
      const data = await response.json()

      if (response.ok) {
        setResult(data)
      } else {
        setError(`HTTP ${response.status}: ${response.statusText}`)
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "การทดสอบ Tesseract.js ล้มเหลว")
    } finally {
      setLoading(false)
    }
  }

  const getResultTitle = () => {
    switch (testType) {
      case "upload":
        return "ผลการประมวลผล PDF"
      case "enhanced":
        return "ผลการประมวลผล PDF (Enhanced AI)"
      case "health":
        return "ผลการตรวจสอบสถานะ"
      case "docs":
        return "เอกสาร API"
      case "test":
        return "ผลการทดสอบ API พื้นฐาน"
      case "openai":
        return "ผลการทดสอบ OpenAI API"
      case "google-vision":
        return "ผลการทดสอบ Google Vision API"
      case "opentyphoon":
        return "ผลการทดสอบ OpenTyphoon API"
      case "huggingface":
        return "ผลการทดสอบ Hugging Face Space"
      case "tesseract":
        return "ผลการทดสอบ Tesseract.js"
      default:
        return "ผลลัพธ์ API"
    }
  }

  const getStatusBadge = (result: any) => {
    if (!result) return null

    if (result.success) {
      return (
        <Badge variant="default" className="bg-green-600">
          สำเร็จ
        </Badge>
      )
    } else {
      return <Badge variant="destructive">ล้มเหลว</Badge>
    }
  }

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-2">แดชบอร์ดทดสอบ API (Enhanced + HF Space)</h1>
          <p className="text-muted-foreground">
            ทดสอบ HF Space + OpenTyphoon + Google Vision + OpenAI API สำหรับประมวลผล PDF
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-6">
          {/* Hugging Face Space Test - เพิ่มก่อน OpenTyphoon */}
          <Card className="border-purple-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-purple-600">
                <Zap className="w-5 h-5" />
                HF Space (คุณ)
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">ทดสอบ HF Space ของคุณเอง</p>
              <div className="text-xs text-muted-foreground bg-purple-50 p-2 rounded">
                protae5544-typhoon-ocr.hf.space
              </div>

              <Button onClick={testHuggingFace} disabled={loading} className="w-full bg-purple-600 hover:bg-purple-700">
                {loading && testType === "huggingface" ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    กำลังทดสอบ...
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 mr-2" />
                    ทดสอบ HF Space
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Tesseract.js Test */}
          <Card className="border-indigo-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-indigo-600">
                <Eye className="w-5 h-5" />
                Tesseract.js
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">OCR ออฟไลน์ รองรับภาษาพม่า</p>
              <div className="text-xs text-muted-foreground bg-indigo-50 p-2 rounded">Thai + English + Myanmar</div>

              <Button onClick={testTesseract} disabled={loading} className="w-full bg-indigo-600 hover:bg-indigo-700">
                {loading && testType === "tesseract" ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    กำลังทดสอบ...
                  </>
                ) : (
                  <>
                    <Eye className="w-4 h-4 mr-2" />
                    ทดสอบ Tesseract
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* OpenTyphoon API Test */}
          <Card className="border-orange-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-orange-600">
                <Zap className="w-5 h-5" />
                OpenTyphoon
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">ทดสอบ OpenTyphoon AI สำหรับ Thai OCR</p>

              <Button onClick={testOpenTyphoon} disabled={loading} className="w-full bg-orange-600 hover:bg-orange-700">
                {loading && testType === "opentyphoon" ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    กำลังทดสอบ...
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 mr-2" />
                    ทดสอบ OpenTyphoon
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Google Vision API Test */}
          <Card className="border-green-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-green-600">
                <Eye className="w-5 h-5" />
                Google Vision
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">ทดสอบ Google Vision API สำหรับ OCR</p>

              <Button onClick={testGoogleVision} disabled={loading} className="w-full bg-green-600 hover:bg-green-700">
                {loading && testType === "google-vision" ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    กำลังทดสอบ...
                  </>
                ) : (
                  <>
                    <Eye className="w-4 h-4 mr-2" />
                    ทดสอบ Google Vision
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* OpenAI API Test */}
          <Card className="border-blue-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-blue-600">
                <Key className="w-5 h-5" />
                OpenAI API
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">ทดสอบการเชื่อมต่อ OpenAI API</p>

              <Button onClick={testOpenAI} disabled={loading} className="w-full bg-blue-600 hover:bg-blue-700">
                {loading && testType === "openai" ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    กำลังทดสอบ...
                  </>
                ) : (
                  <>
                    <Key className="w-4 h-4 mr-2" />
                    ทดสอบ OpenAI
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Enhanced PDF Processing */}
          <Card className="border-purple-200 col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-purple-600">
                <Upload className="w-5 h-5" />
                Enhanced PDF
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="pdf-file-enhanced">เลือกไฟล์ PDF</Label>
                <Input id="pdf-file-enhanced" type="file" accept=".pdf" onChange={handleFileChange} className="mt-1" />
              </div>

              {file && (
                <div className="p-3 bg-muted rounded-lg">
                  <p className="text-sm font-medium">{file.name}</p>
                  <p className="text-xs text-muted-foreground">ขนาด: {(file.size / 1024 / 1024).toFixed(2)} MB</p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <Button
                  onClick={testEnhancedPDFProcessing}
                  disabled={!file || loading}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  {loading && testType === "enhanced" ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Enhanced...
                    </>
                  ) : (
                    <>
                      <Upload className="w-4 h-4 mr-2" />
                      Enhanced Processing
                    </>
                  )}
                </Button>

                <Button onClick={testPDFProcessing} disabled={!file || loading} variant="outline">
                  {loading && testType === "upload" ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Basic...
                    </>
                  ) : (
                    <>
                      <Upload className="w-4 h-4 mr-2" />
                      Basic Processing
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Basic API Tests */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TestTube className="w-5 h-5" />
                ทดสอบพื้นฐาน
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button onClick={testBasicAPI} disabled={loading} variant="default" className="w-full">
                {loading && testType === "test" ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    กำลังทดสอบ...
                  </>
                ) : (
                  <>
                    <TestTube className="w-4 h-4 mr-2" />
                    ทดสอบพื้นฐาน
                  </>
                )}
              </Button>

              <Button onClick={testHealthCheck} disabled={loading} variant="outline" className="w-full">
                {loading && testType === "health" ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    กำลังตรวจสอบ...
                  </>
                ) : (
                  <>
                    <CheckCircle className="w-4 h-4 mr-2" />
                    ตรวจสอบสถานะ
                  </>
                )}
              </Button>

              <Button onClick={testAPIDocumentation} disabled={loading} variant="outline" className="w-full">
                {loading && testType === "docs" ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    กำลังโหลด...
                  </>
                ) : (
                  <>
                    <ExternalLink className="w-4 h-4 mr-2" />
                    ดูเอกสาร
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Error Display */}
        {error && (
          <Card className="border-red-200 bg-red-50 dark:bg-red-950/20">
            <CardContent className="pt-6">
              <div className="flex items-center gap-2 text-red-600 dark:text-red-400">
                <AlertCircle className="w-5 h-5" />
                <span className="font-medium">เกิดข้อผิดพลาด</span>
              </div>
              <p className="text-red-700 dark:text-red-300 mt-2">{error}</p>
            </CardContent>
          </Card>
        )}

        {/* Result Display */}
        {result && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  {getResultTitle()}
                </CardTitle>
                {getStatusBadge(result)}
              </div>
            </CardHeader>
            <CardContent>
              {/* Special handling for HF Space test results */}
              {testType === "huggingface" && (
                <div className="mb-4">
                  {result.success ? (
                    <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                      <h3 className="font-medium text-purple-800 mb-2">✅ Hugging Face Space เชื่อมต่อสำเร็จ!</h3>
                      <p className="text-purple-700 text-sm">{result.message}</p>
                      <div className="mt-2 text-xs text-purple-600">Space URL: {result.spaceUrl}</div>
                      {result.features && (
                        <div className="mt-2">
                          <p className="text-sm text-purple-600">ฟีเจอร์ที่รองรับ:</p>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {result.features.map((feature: string) => (
                              <Badge key={feature} variant="outline" className="text-xs bg-purple-100">
                                {feature}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                      <h3 className="font-medium text-red-800 mb-2">❌ Hugging Face Space เชื่อมต่อไม่สำเร็จ</h3>
                      <p className="text-red-700 text-sm mb-3">{result.message}</p>
                      {result.spaceUrl && <div className="mb-3 text-xs text-red-600">Space URL: {result.spaceUrl}</div>}
                      {result.instructions && (
                        <div>
                          <p className="text-sm font-medium text-red-800 mb-2">วิธีแก้ไข:</p>
                          <ol className="text-sm text-red-700 space-y-1">
                            {result.instructions.map((instruction: string, index: number) => (
                              <li key={index}>{instruction}</li>
                            ))}
                          </ol>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Special handling for Tesseract test results */}
              {testType === "tesseract" && (
                <div className="mb-4">
                  {result.success ? (
                    <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-lg">
                      <h3 className="font-medium text-indigo-800 mb-2">✅ Tesseract.js พร้อมใช้งาน!</h3>
                      <p className="text-indigo-700 text-sm">{result.message}</p>
                      {result.features && (
                        <div className="mt-2">
                          <p className="text-sm text-indigo-600">ฟีเจอร์ที่รองรับ:</p>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {result.features.map((feature: string) => (
                              <Badge key={feature} variant="outline" className="text-xs bg-indigo-100">
                                {feature}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                      {result.advantages && (
                        <div className="mt-3">
                          <p className="text-sm text-indigo-600 mb-1">ข้อดี:</p>
                          <ul className="text-xs text-indigo-700 space-y-1">
                            {result.advantages.map((advantage: string, index: number) => (
                              <li key={index}>{advantage}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                      <h3 className="font-medium text-red-800 mb-2">❌ Tesseract.js ไม่สามารถใช้งานได้</h3>
                      <p className="text-red-700 text-sm mb-3">{result.message}</p>
                      {result.instructions && (
                        <div>
                          <p className="text-sm font-medium text-red-800 mb-2">วิธีแก้ไข:</p>
                          <ol className="text-sm text-red-700 space-y-1">
                            {result.instructions.map((instruction: string, index: number) => (
                              <li key={index}>{instruction}</li>
                            ))}
                          </ol>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Enhanced PDF Processing Results */}
              {testType === "enhanced" && result.success && (
                <div className="mb-4">
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h3 className="font-medium text-purple-800 mb-2">🚀 Enhanced AI Processing สำเร็จ!</h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-3">
                      <div className="text-center">
                        <div className="text-lg font-bold text-purple-600">{result.data?.fields?.length || 0}</div>
                        <div className="text-xs text-purple-700">ฟิลด์ที่ตรวจพบ</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-purple-600">
                          {Math.round((result.data?.confidence || 0) * 100)}%
                        </div>
                        <div className="text-xs text-purple-700">ความมั่นใจ</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-purple-600">{result.data?.aiMethods?.length || 0}</div>
                        <div className="text-xs text-purple-700">AI Methods</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-purple-600">{result.data?.processingTime || 0}ms</div>
                        <div className="text-xs text-purple-700">เวลาประมวลผล</div>
                      </div>
                    </div>
                    {result.data?.aiMethods && (
                      <div className="mt-3">
                        <p className="text-sm text-purple-600 mb-1">AI Methods ที่ใช้:</p>
                        <div className="flex flex-wrap gap-1">
                          {result.data.aiMethods.map((method: string) => (
                            <Badge key={method} variant="outline" className="text-xs bg-purple-100">
                              {method}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              <pre className="bg-muted p-4 rounded-lg overflow-auto text-sm max-h-96">
                {JSON.stringify(result, null, 2)}
              </pre>
            </CardContent>
          </Card>
        )}

        {/* Setup Instructions */}
        <Card>
          <CardHeader>
            <CardTitle>🚀 คำแนะนำการตั้งค่า Enhanced AI + HF Space</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                <h3 className="font-medium text-purple-800 mb-2">
                  1. ใช้ Hugging Face Space ของคุณ (แนะนำ - ไม่ต้องใช้ API Key)
                </h3>
                <ol className="text-sm text-purple-700 space-y-1">
                  <li>• Space URL: https://protae5544-typhoon-ocr.hf.space</li>
                  <li>• ไม่ต้องตั้งค่า API Key</li>
                  <li>• ใช้ GPU ของ Hugging Face ฟรี</li>
                  <li>• เหมาะสำหรับภาษาไทย</li>
                  <li>• กดปุ่ม "ทดสอบ HF Space" เพื่อทดสอบ</li>
                </ol>
              </div>

              <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-lg">
                <h3 className="font-medium text-indigo-800 mb-2">
                  2. ใช้ Tesseract.js (แนะนำ - ไม่ต้องใช้ API Key + รองรับภาษาพม่า)
                </h3>
                <ol className="text-sm text-indigo-700 space-y-1">
                  <li>• ไม่ต้องตั้งค่า API Key</li>
                  <li>• ทำงานออฟไลน์ใน browser</li>
                  <li>• รองรับภาษาไทย, อังกฤษ, และพม่า</li>
                  <li>• ใช้ฟรีตลอดไป</li>
                  <li>• กดปุ่ม "ทดสอบ Tesseract" เพื่อทดสอบ</li>
                  <li>• ช้ากว่า cloud API แต่เชื่อถือได้</li>
                </ol>
              </div>

              <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg">
                <h3 className="font-medium text-gray-800 mb-2">3. ลำดับการทำงานของ AI (Fallback Chain)</h3>
                <ol className="text-sm text-gray-700 space-y-1">
                  <li>
                    • <strong>🚀 HF Space ของคุณ</strong> - ลองก่อน (ใช้ GPU ฟรี)
                  </li>
                  <li>
                    • <strong>🔍 Tesseract.js</strong> - ถ้า HF Space ไม่ได้ (รองรับภาษาพม่า)
                  </li>
                  <li>
                    • <strong>🔄 OpenTyphoon AI</strong> - ถ้า Tesseract ไม่ได้
                  </li>
                  <li>
                    • <strong>👁️ Google Vision</strong> - ถ้า OpenTyphoon ไม่ได้
                  </li>
                  <li>
                    • <strong>🤖 OpenAI GPT-4 Vision</strong> - สำหรับ field detection
                  </li>
                  <li>
                    • <strong>📝 Pattern Matching</strong> - fallback สุดท้าย
                  </li>
                </ol>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Links */}
        <Card>
          <CardHeader>
            <CardTitle>ลิงก์ด่วน</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <a
                href="/api/test-huggingface"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 p-3 border rounded-lg hover:bg-muted transition-colors"
              >
                <ExternalLink className="w-4 h-4" />
                <div>
                  <div className="font-medium">HF Space Test</div>
                  <div className="text-sm text-muted-foreground">GET /api/test-huggingface</div>
                </div>
              </a>

              <a
                href="/api/process-pdf-enhanced"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 p-3 border rounded-lg hover:bg-muted transition-colors"
              >
                <ExternalLink className="w-4 h-4" />
                <div>
                  <div className="font-medium">Enhanced PDF API</div>
                  <div className="text-sm text-muted-foreground">GET /api/process-pdf-enhanced</div>
                </div>
              </a>

              <a
                href="/api/health"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 p-3 border rounded-lg hover:bg-muted transition-colors"
              >
                <ExternalLink className="w-4 h-4" />
                <div>
                  <div className="font-medium">Health Check</div>
                  <div className="text-sm text-muted-foreground">GET /api/health</div>
                </div>
              </a>

              <a href="/" className="flex items-center gap-2 p-3 border rounded-lg hover:bg-muted transition-colors">
                <ExternalLink className="w-4 h-4" />
                <div>
                  <div className="font-medium">แอปหลัก</div>
                  <div className="text-sm text-muted-foreground">PDF Field Editor</div>
                </div>
              </a>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
