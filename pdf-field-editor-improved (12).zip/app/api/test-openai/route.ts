import { NextResponse } from "next/server"

export async function GET() {
  try {
    const apiKey = process.env.NEXT_PUBLIC_OPENAI_API_KEY

    if (!apiKey || apiKey === "demo-key") {
      return NextResponse.json({
        success: false,
        message: "ไม่พบ OpenAI API Key",
        instructions: [
          "1. ไปที่ https://platform.openai.com/api-keys",
          "2. สร้าง API Key ใหม่",
          "3. เพิ่ม NEXT_PUBLIC_OPENAI_API_KEY ใน environment variables",
          "4. Restart แอปพลิเคชัน",
        ],
        status: "no_api_key",
      })
    }

    // Test OpenAI API connection
    const response = await fetch("https://api.openai.com/v1/models", {
      headers: {
        Authorization: `Bearer ${apiKey}`,
      },
    })

    if (response.ok) {
      const data = await response.json()
      const availableModels = data.data
        .filter((model: any) => model.id.includes("gpt"))
        .map((model: any) => model.id)
        .slice(0, 5)

      return NextResponse.json({
        success: true,
        message: "เชื่อมต่อ OpenAI API สำเร็จ! 🎉",
        apiKey: `${apiKey.substring(0, 7)}...${apiKey.substring(apiKey.length - 4)}`,
        availableModels,
        status: "connected",
        timestamp: new Date().toISOString(),
      })
    } else {
      const errorData = await response.json().catch(() => ({}))

      return NextResponse.json({
        success: false,
        message: "OpenAI API Key ไม่ถูกต้อง",
        error: errorData.error?.message || `HTTP ${response.status}`,
        instructions: [
          "1. ตรวจสอบ API Key ให้ถูกต้อง",
          "2. ตรวจสอบว่า API Key ยังไม่หมดอายุ",
          "3. ตรวจสอบ billing account ใน OpenAI",
        ],
        status: "invalid_key",
      })
    }
  } catch (error) {
    return NextResponse.json({
      success: false,
      message: "ไม่สามารถเชื่อมต่อ OpenAI API ได้",
      error: error instanceof Error ? error.message : "Unknown error",
      status: "connection_error",
    })
  }
}
