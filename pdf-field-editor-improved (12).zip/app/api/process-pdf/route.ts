import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get("file") as File

    if (!file) {
      return NextResponse.json(
        {
          success: false,
          error: "ไม่พบไฟล์",
          code: "MISSING_FILE",
        },
        { status: 400 },
      )
    }

    if (file.type !== "application/pdf") {
      return NextResponse.json(
        {
          success: false,
          error: "ไฟล์ต้องเป็น PDF เท่านั้น",
          code: "INVALID_FILE_TYPE",
          received: file.type,
        },
        { status: 400 },
      )
    }

    // Check file size (limit to 10MB)
    if (file.size > 10 * 1024 * 1024) {
      return NextResponse.json(
        {
          success: false,
          error: "ไฟล์ใหญ่เกินไป (สูงสุด 10MB)",
          code: "FILE_TOO_LARGE",
        },
        { status: 400 },
      )
    }

    // Simulate processing steps
    const processingSteps = [
      { step: "อ่านไฟล์ PDF", delay: 500 },
      { step: "แปลงเป็นรูปภาพ", delay: 1000 },
      { step: "จำแนกประเภทเอกสาร", delay: 800 },
      { step: "ตรวจจับฟิลด์ด้วย AI", delay: 1500 },
      { step: "สร้าง template", delay: 300 },
    ]

    // Simulate processing delay
    for (const step of processingSteps) {
      await new Promise((resolve) => setTimeout(resolve, step.delay))
    }

    // Classify document type based on filename
    const documentType = classifyDocument(file.name)

    // Generate mock fields based on document type
    const fields = generateFieldsForDocumentType(documentType.type)

    const response = {
      success: true,
      message: "ประมวลผล PDF สำเร็จ",
      data: {
        filename: file.name,
        fileSize: file.size,
        documentType: documentType.type,
        documentName: documentType.name,
        confidence: documentType.confidence,
        fields: fields,
        ocrText: `ข้อความที่แยกได้จาก ${file.name}...`,
        pages: 1,
        processedAt: new Date().toISOString(),
        processingTime: processingSteps.reduce((sum, step) => sum + step.delay, 0),
      },
    }

    return NextResponse.json(response, {
      status: 200,
      headers: {
        "Content-Type": "application/json",
      },
    })
  } catch (error) {
    console.error("PDF processing error:", error)

    return NextResponse.json(
      {
        success: false,
        error: "เกิดข้อผิดพลาดในการประมวลผล PDF",
        code: "PROCESSING_ERROR",
        details: error instanceof Error ? error.message : "Unknown error",
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}

function classifyDocument(filename: string): { type: string; name: string; confidence: number } {
  const documentTypes = [
    {
      pattern: /บต\.?\s*44|WP\.?\s*44|work.*permit.*change/i,
      type: "work-permit-change",
      name: "คำขอเปลี่ยนรายการในใบอนุญาตทำงาน (บต.44)",
      confidence: 0.95,
    },
    {
      pattern: /บต\.?\s*46|WP\.?\s*46|employment.*cert/i,
      type: "employment-cert",
      name: "หนังสือรับรองการจ้าง (บต.46)",
      confidence: 0.95,
    },
    {
      pattern: /power.*attorney|หนังสือมอบอำนาจ/i,
      type: "power-of-attorney",
      name: "หนังสือมอบอำนาจ",
      confidence: 0.9,
    },
    {
      pattern: /contract|สัญญา/i,
      type: "employment-contract",
      name: "สัญญาจ้างงาน",
      confidence: 0.85,
    },
  ]

  for (const docType of documentTypes) {
    if (docType.pattern.test(filename)) {
      return {
        type: docType.type,
        name: docType.name,
        confidence: docType.confidence,
      }
    }
  }

  return {
    type: "unknown",
    name: "เอกสารไม่ทราบประเภท",
    confidence: 0.3,
  }
}

function generateFieldsForDocumentType(documentType: string): any[] {
  const fieldTemplates: Record<string, any[]> = {
    "work-permit-change": [
      {
        id: "wp-name",
        name: "ชื่อผู้ยื่นคำขอ",
        type: "text",
        x: 150,
        y: 120,
        width: 200,
        height: 20,
        page: 1,
        confidence: 0.92,
        required: true,
      },
      {
        id: "wp-nationality",
        name: "สัญชาติ",
        type: "text",
        x: 100,
        y: 150,
        width: 150,
        height: 20,
        page: 1,
        confidence: 0.88,
        required: true,
      },
      {
        id: "wp-permit-number",
        name: "เลขที่ใบอนุญาตทำงาน",
        type: "text",
        x: 200,
        y: 180,
        width: 180,
        height: 20,
        page: 1,
        confidence: 0.85,
        required: true,
      },
      {
        id: "wp-issue-date",
        name: "วันที่ออกใบอนุญาต",
        type: "date",
        x: 150,
        y: 210,
        width: 120,
        height: 20,
        page: 1,
        confidence: 0.9,
        required: true,
        format: "DD/MM/YYYY",
      },
      {
        id: "wp-signature",
        name: "ลายเซ็นผู้ยื่นคำขอ",
        type: "signature",
        x: 300,
        y: 400,
        width: 150,
        height: 50,
        page: 1,
        confidence: 0.95,
        required: true,
      },
    ],
    "employment-cert": [
      {
        id: "emp-employer-name",
        name: "ชื่อนายจ้าง",
        type: "text",
        x: 120,
        y: 200,
        width: 250,
        height: 20,
        page: 1,
        confidence: 0.94,
        required: true,
      },
      {
        id: "emp-address",
        name: "ที่อยู่สถานประกอบการ",
        type: "text",
        x: 100,
        y: 230,
        width: 300,
        height: 40,
        page: 1,
        confidence: 0.89,
        required: true,
      },
      {
        id: "emp-business-type",
        name: "ประเภทกิจการ",
        type: "text",
        x: 150,
        y: 280,
        width: 200,
        height: 20,
        page: 1,
        confidence: 0.86,
        required: true,
      },
      {
        id: "emp-employee-name",
        name: "ชื่อลูกจ้าง",
        type: "text",
        x: 140,
        y: 320,
        width: 200,
        height: 20,
        page: 1,
        confidence: 0.91,
        required: true,
      },
    ],
  }

  return fieldTemplates[documentType] || []
}

// Handle GET requests for API documentation
export async function GET() {
  try {
    const documentation = {
      success: true,
      message: "PDF Processing API Documentation",
      description: "API สำหรับประมวลผลเอกสาร PDF และตรวจจับฟิลด์อัตโนมัติ",
      version: "1.0.0",
      endpoints: {
        process: {
          url: "/api/process-pdf",
          method: "POST",
          contentType: "multipart/form-data",
          parameters: {
            file: {
              type: "File",
              required: true,
              description: "ไฟล์ PDF ที่ต้องการประมวลผล",
              accepts: "application/pdf",
              maxSize: "10MB",
            },
          },
          response: {
            success: "boolean",
            message: "string",
            data: {
              filename: "ชื่อไฟล์",
              fileSize: "ขนาดไฟล์ (bytes)",
              documentType: "ประเภทเอกสาร",
              documentName: "ชื่อเอกสาร",
              confidence: "ความมั่นใจ (0-1)",
              fields: "array ของฟิลด์ที่ตรวจพบ",
              ocrText: "ข้อความที่แยกได้",
              pages: "จำนวนหน้า",
              processedAt: "เวลาที่ประมวลผล",
              processingTime: "เวลาที่ใช้ประมวลผล (ms)",
            },
          },
        },
        health: {
          url: "/api/health",
          method: "GET",
          description: "ตรวจสอบสถานะ API",
        },
      },
      supportedDocuments: [
        "คำขอเปลี่ยนรายการในใบอนุญาตทำงาน (บต.44)",
        "หนังสือรับรองการจ้าง (บต.46)",
        "หนังสือมอบอำนาจ",
        "สัญญาจ้างงาน",
      ],
      usage: {
        javascript: `
// JavaScript example
const formData = new FormData();
formData.append('file', pdfFile);

fetch('/api/process-pdf', {
  method: 'POST',
  body: formData
})
.then(response => response.json())
.then(data => {
  if (data.success) {
    console.log('ตรวจพบฟิลด์:', data.data.fields);
  } else {
    console.error('เกิดข้อผิดพลาด:', data.error);
  }
});`,
        curl: `
# cURL example
curl -X POST \\
  -F "file=@document.pdf" \\
  http://localhost:3000/api/process-pdf`,
      },
      timestamp: new Date().toISOString(),
    }

    return NextResponse.json(documentation, {
      status: 200,
      headers: {
        "Content-Type": "application/json",
      },
    })
  } catch (error) {
    console.error("Documentation error:", error)

    return NextResponse.json(
      {
        success: false,
        error: "ไม่สามารถโหลดเอกสาร API ได้",
        details: error instanceof Error ? error.message : "Unknown error",
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}

export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  })
}
