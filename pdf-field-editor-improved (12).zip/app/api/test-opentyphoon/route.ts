import { NextResponse } from "next/server"

export async function GET() {
  try {
    const apiKey = process.env.NEXT_PUBLIC_OPENTYPHOON_API_KEY

    if (!apiKey || apiKey === "demo-key") {
      return NextResponse.json({
        success: false,
        message: "ไม่พบ OpenTyphoon API Key",
        instructions: [
          "1. ไปที่ https://docs.opentyphoon.ai/",
          "2. สร้าง API Key",
          "3. เพิ่ม NEXT_PUBLIC_OPENTYPHOON_API_KEY ใน environment variables",
          "4. Restart แอปพลิเคชัน",
        ],
        status: "no_api_key",
      })
    }

    // Test OpenTyphoon API connection
    const testImage = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/5+hHgAHggJ/PchI7wAAAABJRU5ErkJggg=="

    const response = await fetch("https://api.opentyphoon.ai/v1/ocr", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "typhoon-ocr",
        image: testImage,
        language: "th",
      }),
    })

    if (response.ok) {
      const data = await response.json()

      return NextResponse.json({
        success: true,
        message: "เชื่อมต่อ OpenTyphoon API สำเร็จ! 🎉",
        apiKey: `${apiKey.substring(0, 7)}...${apiKey.substring(apiKey.length - 4)}`,
        status: "connected",
        timestamp: new Date().toISOString(),
        model: "typhoon-ocr",
        features: ["Thai OCR", "Form Detection", "Table Extraction"],
        testResult: {
          hasResponse: !!data,
          confidence: data?.confidence || 0,
        },
      })
    } else {
      const errorData = await response.json().catch(() => ({}))

      return NextResponse.json({
        success: false,
        message: "OpenTyphoon API Key ไม่ถูกต้อง",
        error: errorData.error?.message || `HTTP ${response.status}`,
        instructions: [
          "1. ตรวจสอบ API Key ให้ถูกต้อง",
          "2. ตรวจสอบว่า API Key ยังไม่หมดอายุ",
          "3. ตรวจสอบ rate limits (2 req/s, 20 req/m)",
        ],
        status: "invalid_key",
      })
    }
  } catch (error) {
    return NextResponse.json({
      success: false,
      message: "ไม่สามารถเชื่อมต่อ OpenTyphoon API ได้",
      error: error instanceof Error ? error.message : "Unknown error",
      status: "connection_error",
    })
  }
}
