import { NextResponse } from "next/server"

export async function GET() {
  try {
    const testResponse = {
      success: true,
      message: "API is working correctly",
      timestamp: new Date().toISOString(),
      test_data: {
        string: "Hello World",
        number: 42,
        boolean: true,
        array: [1, 2, 3],
        object: {
          nested: "value",
        },
      },
    }

    return NextResponse.json(testResponse)
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: "Test failed",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
