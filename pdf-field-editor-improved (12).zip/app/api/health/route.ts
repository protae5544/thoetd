import { NextResponse } from "next/server"

export async function GET() {
  try {
    // Get current timestamp
    const timestamp = new Date().toISOString()

    // Simple health check without Node.js specific APIs
    const healthData = {
      success: true,
      status: "healthy",
      timestamp,
      version: "1.0.0",
      services: {
        api: "running",
        pdf_processor: "ready",
        ai_integration: "configured",
        database: "not_connected", // Since we're using localStorage
      },
      environment: "production", // Default to production
      server: {
        status: "online",
        region: "global",
      },
      features: {
        pdf_processing: true,
        ai_detection: true,
        batch_processing: true,
        template_management: true,
      },
    }

    return NextResponse.json(healthData, {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "no-cache",
      },
    })
  } catch (error) {
    console.error("Health check error:", error)

    // Return a simple error response
    const errorResponse = {
      success: false,
      status: "unhealthy",
      error: "Health check failed",
      timestamp: new Date().toISOString(),
      details: error instanceof Error ? error.message : "Unknown error occurred",
    }

    return NextResponse.json(errorResponse, {
      status: 500,
      headers: {
        "Content-Type": "application/json",
      },
    })
  }
}

// Add OPTIONS method for CORS if needed
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  })
}
