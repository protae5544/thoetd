import { NextResponse } from "next/server"

export async function GET() {
  try {
    console.log("🧪 ทดสอบ Tesseract.js...")

    // Since Tesseract runs on client-side, we'll return setup instructions
    return NextResponse.json({
      success: true,
      message: "Tesseract.js พร้อมใช้งาน! (Client-side OCR)",
      description: "Tesseract.js ทำงานใน browser ไม่ต้องใช้ API Key",
      features: [
        "Thai OCR (ภาษาไทย)",
        "English OCR (ภาษาอังกฤษ)",
        "Myanmar OCR (ภาษาพม่า)",
        "Offline Processing (ทำงานออฟไลน์)",
        "No API Key Required (ไม่ต้องใช้ API Key)",
        "Free Forever (ใช้ฟรีตลอดไป)",
      ],
      languages: ["tha", "eng", "mya"],
      installation: {
        package: "tesseract.js",
        version: "latest",
        size: "~2MB download",
        performance: "Medium (ช้ากว่า cloud API แต่ทำงานออฟไลน์ได้)",
      },
      usage: {
        initialization: "Auto-initialize เมื่อใช้งานครั้งแรก",
        processing: "ประมวลผลใน browser",
        memory: "ใช้ RAM ประมาณ 50-100MB",
      },
      advantages: [
        "✅ ไม่ต้องใช้ API Key",
        "✅ ทำงานออฟไลน์ได้",
        "✅ รองรับภาษาพม่า",
        "✅ ฟรีตลอดไป",
        "✅ ความเป็นส่วนตัวสูง (ไม่ส่งข้อมูลออกไป)",
      ],
      disadvantages: ["⚠️ ช้ากว่า cloud API", "⚠️ ใช้ RAM มาก", "⚠️ ความแม่นยำต่ำกว่า AI models"],
      testInstructions: [
        "1. ไปที่หน้า /api-test",
        "2. กดปุ่ม 'ทดสอบ Tesseract'",
        "3. อัปโหลด PDF เพื่อทดสอบ",
        "4. รอการประมวลผล (อาจใช้เวลา 10-30 วินาที)",
      ],
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("❌ Tesseract test error:", error)

    return NextResponse.json({
      success: false,
      message: "เกิดข้อผิดพลาดในการทดสอบ Tesseract.js",
      error: error instanceof Error ? error.message : "Unknown error",
      instructions: [
        "1. ตรวจสอบว่า browser รองรับ WebAssembly",
        "2. ลองรีเฟรชหน้าเว็บ",
        "3. ตรวจสอบ console สำหรับ error messages",
      ],
    })
  }
}

export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  })
}
