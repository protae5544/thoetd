import { NextResponse } from "next/server"

export async function GET() {
  try {
    const apiKey = process.env.NEXT_PUBLIC_GOOGLE_VISION_API_KEY

    if (!apiKey || apiKey === "demo-key") {
      return NextResponse.json({
        success: false,
        message: "ไม่พบ Google Vision API Key",
        instructions: [
          "1. ไปที่ Google Cloud Console",
          "2. เปิดใช้งาน Vision API",
          "3. สร้าง API Key",
          "4. เพิ่ม NEXT_PUBLIC_GOOGLE_VISION_API_KEY ใน environment variables",
          "5. Restart แอปพลิเคชัน",
        ],
        status: "no_api_key",
      })
    }

    // Test Google Vision API connection
    const testImage = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/5+hHgAHggJ/PchI7wAAAABJRU5ErkJggg=="

    const response = await fetch(`https://vision.googleapis.com/v1/images:annotate?key=${apiKey}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        requests: [
          {
            image: {
              content: testImage,
            },
            features: [
              {
                type: "TEXT_DETECTION",
                maxResults: 1,
              },
            ],
          },
        ],
      }),
    })

    if (response.ok) {
      const data = await response.json()

      return NextResponse.json({
        success: true,
        message: "เชื่อมต่อ Google Vision API สำเร็จ! 🎉",
        apiKey: `${apiKey.substring(0, 7)}...${apiKey.substring(apiKey.length - 4)}`,
        status: "connected",
        timestamp: new Date().toISOString(),
        testResult: {
          hasResponses: data.responses && data.responses.length > 0,
          responseCount: data.responses?.length || 0,
        },
      })
    } else {
      const errorData = await response.json().catch(() => ({}))

      return NextResponse.json({
        success: false,
        message: "Google Vision API Key ไม่ถูกต้อง",
        error: errorData.error?.message || `HTTP ${response.status}`,
        instructions: [
          "1. ตรวจสอบ API Key ให้ถูกต้อง",
          "2. ตรวจสอบว่าเปิดใช้งาน Vision API แล้ว",
          "3. ตรวจสอบ quota และ billing",
        ],
        status: "invalid_key",
      })
    }
  } catch (error) {
    return NextResponse.json({
      success: false,
      message: "ไม่สามารถเชื่อมต่อ Google Vision API ได้",
      error: error instanceof Error ? error.message : "Unknown error",
      status: "connection_error",
    })
  }
}
