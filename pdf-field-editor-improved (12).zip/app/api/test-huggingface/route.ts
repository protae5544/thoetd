import { NextResponse } from "next/server"

export async function GET() {
  try {
    console.log("🧪 ทดสอบการเชื่อมต่อ Hugging Face Space...")

    const spaceUrl = "https://protae5544-typhoon-ocr.hf.space"

    // Test different possible endpoints
    const endpoints = [
      `${spaceUrl}/api/predict`,
      `${spaceUrl}/gradio_api/call/predict`,
      `${spaceUrl}/call/predict`,
      `${spaceUrl}/run/predict`,
    ]

    // Create a simple test image (1x1 pixel PNG)
    const testImageBase64 =
      "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/5+hHgAHggJ/PchI7wAAAABJRU5ErkJggg=="

    let lastError = ""

    for (const endpoint of endpoints) {
      try {
        console.log(`🔄 ลอง endpoint: ${endpoint}`)

        const response = await fetch(endpoint, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
          body: JSON.stringify({
            data: [testImageBase64],
            fn_index: 0,
          }),
        })

        console.log(`📡 Response status: ${response.status}`)

        if (response.ok) {
          const result = await response.json()
          console.log(`✅ สำเร็จที่ endpoint: ${endpoint}`)

          return NextResponse.json({
            success: true,
            message: "เชื่อมต่อ Hugging Face Space สำเร็จ! 🎉",
            spaceUrl: spaceUrl,
            workingEndpoint: endpoint,
            testResult: result,
            features: ["Thai OCR", "PDF Processing", "Form Detection", "Multi-language Support"],
          })
        } else {
          const errorText = await response.text()
          lastError = `${response.status}: ${errorText}`
          console.warn(`⚠️ ล้มเหลวที่ endpoint: ${endpoint} - ${lastError}`)
        }
      } catch (error) {
        lastError = error instanceof Error ? error.message : "Unknown error"
        console.warn(`⚠️ ล้มเหลวที่ endpoint: ${endpoint} - ${lastError}`)
        continue
      }
    }

    // If all endpoints failed
    return NextResponse.json({
      success: false,
      message: "ไม่สามารถเชื่อมต่อ Hugging Face Space ได้",
      spaceUrl: spaceUrl,
      lastError: lastError,
      instructions: [
        "1. ตรวจสอบว่า Space ไม่ได้ sleep (เปิด URL ในเบราว์เซอร์)",
        "2. รอให้ Space boot up (อาจใช้เวลา 1-2 นาที)",
        "3. ลองรีเฟรช Space ใน Hugging Face",
        "4. ตรวจสอบว่า Space เป็น public",
        "5. ลองใช้ Tesseract.js แทน (จะเพิ่มให้)",
      ],
      testedEndpoints: endpoints,
    })
  } catch (error) {
    console.error("❌ HF Space test error:", error)

    return NextResponse.json({
      success: false,
      message: "เกิดข้อผิดพลาดในการทดสอบ Hugging Face Space",
      error: error instanceof Error ? error.message : "Unknown error",
      instructions: ["1. ตรวจสอบการเชื่อมต่ออินเทอร์เน็ต", "2. ลองใช้ Tesseract.js แทน", "3. ตรวจสอบ Space URL"],
    })
  }
}

export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  })
}
