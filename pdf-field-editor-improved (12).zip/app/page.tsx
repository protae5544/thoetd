"use client"

import type React from "react"
import { useState, useCallback, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Upload, FileText, Zap } from "lucide-react"

// Import components directly without dynamic imports to avoid hook issues
import { DocumentClassifier } from "@/components/document-classifier"
import { FieldDetector } from "@/components/field-detector"
import { ResultExporter } from "@/components/result-exporter"
import { FieldEditor } from "@/components/field-editor"

interface ProcessedDocument {
  id: string
  name: string
  type: string
  originalFile: File
  pages: number
  status: "pending" | "processing" | "detected" | "confirmed" | "completed"
  fields: DetectedField[]
  ocrText?: string
  confidence: number
}

interface DetectedField {
  id: string
  name: string
  type: "text" | "number" | "date" | "checkbox" | "signature"
  x: number
  y: number
  width: number
  height: number
  page: number
  confidence: number
  value?: string
  required: boolean
  format?: string
}

export default function PDFDocumentProcessor() {
  const [documents, setDocuments] = useState<ProcessedDocument[]>([])
  const [currentDocument, setCurrentDocument] = useState<ProcessedDocument | null>(null)
  const [processing, setProcessing] = useState(false)
  const [currentStep, setCurrentStep] = useState<
    "upload" | "classify" | "detect" | "edit" | "export" | "batch" | "templates"
  >("upload")
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileUpload = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || [])
    if (files.length === 0) return

    setProcessing(true)
    setCurrentStep("classify")

    const newDocuments: ProcessedDocument[] = []

    for (const file of files) {
      if (file.type === "application/pdf") {
        const doc: ProcessedDocument = {
          id: `doc-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          name: file.name,
          type: "unknown",
          originalFile: file,
          pages: 1,
          status: "pending",
          fields: [],
          confidence: 0,
        }
        newDocuments.push(doc)
      }
    }

    setDocuments((prev) => [...prev, ...newDocuments])

    // Start processing pipeline
    await processDocuments(newDocuments)
    setProcessing(false)
  }, [])

  const processDocuments = async (docs: ProcessedDocument[]) => {
    for (const doc of docs) {
      await classifyDocument(doc)
      await detectFields(doc)
    }
    setCurrentStep("edit")
  }

  const classifyDocument = async (doc: ProcessedDocument) => {
    setDocuments((prev) => prev.map((d) => (d.id === doc.id ? { ...d, status: "processing" } : d)))

    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const documentTypes = [
        { pattern: /บต\.?\s*44|WP\.?\s*44/i, type: "work-permit-change", name: "คำขอเปลี่ยนรายการในใบอนุญาตทำงาน" },
        { pattern: /บต\.?\s*46|WP\.?\s*46/i, type: "employment-cert", name: "หนังสือรับรองการจ้าง" },
        { pattern: /power.*attorney|หนังสือมอบอำนาจ/i, type: "power-of-attorney", name: "หนังสือมอบอำนาจ" },
        { pattern: /employment.*contract|สัญญาจ้าง/i, type: "employment-contract", name: "สัญญาจ้างงาน" },
      ]

      let detectedType = "unknown"
      let detectedName = doc.name

      for (const docType of documentTypes) {
        if (docType.pattern.test(doc.name)) {
          detectedType = docType.type
          detectedName = docType.name
          break
        }
      }

      setDocuments((prev) =>
        prev.map((d) =>
          d.id === doc.id
            ? {
                ...d,
                type: detectedType,
                name: detectedName,
                status: "detected",
                confidence: detectedType !== "unknown" ? 0.95 : 0.3,
              }
            : d,
        ),
      )
    } catch (error) {
      console.error("Classification error:", error)
    }
  }

  const detectFields = async (doc: ProcessedDocument) => {
    try {
      await new Promise((resolve) => setTimeout(resolve, 2000))

      const mockFields = generateMockFields(doc.type)

      setDocuments((prev) =>
        prev.map((d) =>
          d.id === doc.id
            ? {
                ...d,
                fields: mockFields,
                status: "detected",
                confidence: 0.85,
              }
            : d,
        ),
      )
    } catch (error) {
      console.error("Field detection error:", error)
    }
  }

  const generateMockFields = (docType: string): DetectedField[] => {
    const baseFields: Record<string, DetectedField[]> = {
      "work-permit-change": [
        {
          id: "field-1",
          name: "ชื่อผู้ยื่นคำขอ",
          type: "text",
          x: 150,
          y: 120,
          width: 200,
          height: 20,
          page: 1,
          confidence: 0.9,
          required: true,
        },
        {
          id: "field-2",
          name: "สัญชาติ",
          type: "text",
          x: 100,
          y: 150,
          width: 150,
          height: 20,
          page: 1,
          confidence: 0.85,
          required: true,
        },
        {
          id: "field-3",
          name: "เลขที่ใบอนุญาตทำงาน",
          type: "text",
          x: 200,
          y: 180,
          width: 180,
          height: 20,
          page: 1,
          confidence: 0.88,
          required: true,
        },
      ],
      "employment-cert": [
        {
          id: "field-1",
          name: "ชื่อนายจ้าง",
          type: "text",
          x: 120,
          y: 200,
          width: 250,
          height: 20,
          page: 1,
          confidence: 0.92,
          required: true,
        },
        {
          id: "field-2",
          name: "ที่อยู่สถานประกอบการ",
          type: "text",
          x: 100,
          y: 230,
          width: 300,
          height: 20,
          page: 1,
          confidence: 0.87,
          required: true,
        },
      ],
    }

    return baseFields[docType] || []
  }

  const confirmDocument = async (doc: ProcessedDocument) => {
    setDocuments((prev) => prev.map((d) => (d.id === doc.id ? { ...d, status: "confirmed" } : d)))
    setCurrentStep("export")
  }

  const exportResults = async (doc: ProcessedDocument) => {
    const jsonTemplate = {
      documentType: doc.type,
      documentName: doc.name,
      fields: doc.fields.map((field) => ({
        id: field.id,
        name: field.name,
        type: field.type,
        required: field.required,
        format: field.format,
        position: {
          x: field.x,
          y: field.y,
          width: field.width,
          height: field.height,
          page: field.page,
        },
      })),
      metadata: {
        confidence: doc.confidence,
        pages: doc.pages,
        processedAt: new Date().toISOString(),
      },
    }

    const csvHeaders = doc.fields.map((f) => f.name).join(",")
    const csvTemplate = `${csvHeaders}\n${doc.fields.map(() => "").join(",")}`

    const jsonBlob = new Blob([JSON.stringify(jsonTemplate, null, 2)], { type: "application/json" })
    const csvBlob = new Blob([csvTemplate], { type: "text/csv" })

    const jsonUrl = URL.createObjectURL(jsonBlob)
    const csvUrl = URL.createObjectURL(csvBlob)

    const jsonLink = document.createElement("a")
    jsonLink.href = jsonUrl
    jsonLink.download = `${doc.name.replace(/\.[^/.]+$/, "")}_template.json`
    jsonLink.click()

    const csvLink = document.createElement("a")
    csvLink.href = csvUrl
    csvLink.download = `${doc.name.replace(/\.[^/.]+$/, "")}_template.csv`
    csvLink.click()

    setDocuments((prev) => prev.map((d) => (d.id === doc.id ? { ...d, status: "completed" } : d)))
  }

  const getStatusColor = (status: ProcessedDocument["status"]) => {
    switch (status) {
      case "pending":
        return "bg-gray-500"
      case "processing":
        return "bg-blue-500"
      case "detected":
        return "bg-yellow-500"
      case "confirmed":
        return "bg-green-500"
      case "completed":
        return "bg-emerald-500"
      default:
        return "bg-gray-500"
    }
  }

  const getStatusText = (status: ProcessedDocument["status"]) => {
    switch (status) {
      case "pending":
        return "รอประมวลผล"
      case "processing":
        return "กำลังประมวลผล"
      case "detected":
        return "ตรวจจับฟิลด์แล้ว"
      case "confirmed":
        return "ยืนยันแล้ว"
      case "completed":
        return "เสร็จสิ้น"
      default:
        return "ไม่ทราบสถานะ"
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-primary">PDF Document Processor</h1>
              <p className="text-muted-foreground">ระบบประมวลผลเอกสาร PDF อัตโนมัติด้วย AI</p>
            </div>
            <Button onClick={() => fileInputRef.current?.click()} disabled={processing}>
              <Upload className="w-4 h-4 mr-2" />
              อัปโหลดเอกสาร
            </Button>
          </div>
        </div>
      </header>

      <input ref={fileInputRef} type="file" accept=".pdf" multiple onChange={handleFileUpload} className="hidden" />

      <div className="container mx-auto p-4">
        <Tabs value={currentStep} className="w-full">
          <TabsList className="grid w-full grid-cols-7">
            <TabsTrigger value="upload">อัปโหลด</TabsTrigger>
            <TabsTrigger value="classify">จำแนกเอกสาร</TabsTrigger>
            <TabsTrigger value="detect">ตรวจจับฟิลด์</TabsTrigger>
            <TabsTrigger value="edit">แก้ไข/ยืนยัน</TabsTrigger>
            <TabsTrigger value="batch">ประมวลผลแบบกลุ่ม</TabsTrigger>
            <TabsTrigger value="templates">จัดการ Template</TabsTrigger>
            <TabsTrigger value="export">ส่งออกผลลัพธ์</TabsTrigger>
          </TabsList>

          <TabsContent value="upload" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>อัปโหลดเอกสาร PDF</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center">
                  <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-lg mb-2">ลากไฟล์มาวางที่นี่ หรือคลิกเพื่อเลือกไฟล์</p>
                  <p className="text-muted-foreground mb-4">รองรับไฟล์ PDF เท่านั้น (สามารถเลือกหลายไฟล์)</p>
                  <Button onClick={() => fileInputRef.current?.click()}>เลือกไฟล์</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="classify" className="mt-6">
            <DocumentClassifier documents={documents} />
          </TabsContent>

          <TabsContent value="detect" className="mt-6">
            <FieldDetector documents={documents} />
          </TabsContent>

          <TabsContent value="edit" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-1">
                <Card>
                  <CardHeader>
                    <CardTitle>รายการเอกสาร</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {documents.map((doc) => (
                        <div
                          key={doc.id}
                          className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                            currentDocument?.id === doc.id
                              ? "border-primary bg-primary/5"
                              : "border-border hover:bg-muted/50"
                          }`}
                          onClick={() => setCurrentDocument(doc)}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <FileText className="w-4 h-4" />
                              <span className="font-medium text-sm">{doc.name}</span>
                            </div>
                            <Badge className={getStatusColor(doc.status)}>{getStatusText(doc.status)}</Badge>
                          </div>
                          <div className="text-xs text-muted-foreground">
                            ประเภท: {doc.type} • ฟิลด์: {doc.fields.length} • ความมั่นใจ: {Math.round(doc.confidence * 100)}
                            %
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="lg:col-span-2">
                {currentDocument ? (
                  <FieldEditor
                    document={currentDocument}
                    onUpdate={(updatedDoc) => {
                      setDocuments((prev) => prev.map((d) => (d.id === updatedDoc.id ? updatedDoc : d)))
                      setCurrentDocument(updatedDoc)
                    }}
                    onConfirm={() => confirmDocument(currentDocument)}
                  />
                ) : (
                  <Card>
                    <CardContent className="p-8 text-center text-muted-foreground">
                      <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>เลือกเอกสารเพื่อแก้ไขฟิลด์</p>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="batch" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>ประมวลผลแบบกลุ่ม</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8 text-muted-foreground">
                  <p>ฟีเจอร์ประมวลผลแบบกลุ่มจะเปิดใช้งานเร็วๆ นี้</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="templates" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>จัดการ Template</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8 text-muted-foreground">
                  <p>ฟีเจอร์จัดการ Template จะเปิดใช้งานเร็วๆ นี้</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="export" className="mt-6">
            <ResultExporter
              documents={documents.filter((d) => d.status === "confirmed" || d.status === "completed")}
              onExport={exportResults}
            />
          </TabsContent>
        </Tabs>

        {processing && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <Card className="w-96">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="w-5 h-5 animate-pulse" />
                  กำลังประมวลผล...
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Progress value={66} className="mb-2" />
                <p className="text-sm text-muted-foreground">กำลังใช้ AI ตรวจจับฟิลด์ในเอกสาร...</p>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
