"use client"

// Enhanced Tesseract.js OCR Client with comprehensive text extraction
export class TesseractClient {
  private worker: any = null
  private isInitialized = false

  async initialize(): Promise<void> {
    if (this.isInitialized) return

    try {
      console.log("🔧 กำลังเริ่มต้น Tesseract.js...")

      // Dynamic import Tesseract.js
      const Tesseract = await import("tesseract.js")

      // Create worker with Thai, English, and Myanmar support
      this.worker = await Tesseract.createWorker("tha+eng+mya", 1, {
        logger: (m: any) => {
          if (m.status === "recognizing text") {
            console.log(`📖 Tesseract progress: ${Math.round(m.progress * 100)}%`)
          }
        },
      })

      // Configure Tesseract for better accuracy
      await this.worker.setParameters({
        tessedit_char_whitelist: "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzก-๙ .,/:-()[]{}",
        tessedit_pageseg_mode: Tesseract.PSM.AUTO,
        preserve_interword_spaces: "1",
        tessedit_create_hocr: "1",
        tessedit_create_tsv: "1",
      })

      this.isInitialized = true
      console.log("✅ Tesseract.js พร้อมใช้งาน (Thai + English + Myanmar)")
    } catch (error) {
      console.error("❌ Tesseract.js initialization failed:", error)
      throw new Error("Failed to initialize Tesseract.js")
    }
  }

  async performOCR(imageData: string): Promise<any> {
    try {
      if (!this.isInitialized) {
        await this.initialize()
      }

      console.log("🔍 เริ่ม OCR ด้วย Tesseract.js...")

      // Convert base64 to image element for better processing
      const imageElement = await this.base64ToImageElement(imageData)

      // Perform OCR with detailed output
      const result = await this.worker.recognize(imageElement, {
        rectangle: undefined, // Process entire image
      })

      console.log("✅ Tesseract OCR เสร็จสิ้น")
      console.log("📄 ข้อความที่ตรวจพบ:", result.data.text.length, "ตัวอักษร")

      // Extract comprehensive data
      const extractedData = {
        text: this.cleanText(result.data.text) || "",
        confidence: (result.data.confidence || 80) / 100,
        blocks: this.extractBlocks(result.data),
        words: this.extractWords(result.data),
        lines: this.extractLines(result.data),
        paragraphs: this.extractParagraphs(result.data),
        tables: this.detectTables(result.data),
        forms: this.detectFormStructure(result.data),
        language: this.detectLanguage(result.data.text),
        provider: "tesseract",
        rawData: result.data,
        statistics: {
          totalWords: result.data.words?.length || 0,
          totalLines: result.data.lines?.length || 0,
          totalParagraphs: result.data.paragraphs?.length || 0,
          averageConfidence: this.calculateAverageConfidence(result.data),
        },
      }

      console.log("📊 สถิติ OCR:", extractedData.statistics)
      return extractedData
    } catch (error) {
      console.error("❌ Tesseract OCR error:", error)
      throw new Error("Tesseract OCR failed")
    }
  }

  async detectFormFields(imageData: string): Promise<any> {
    try {
      const ocrResult = await this.performOCR(imageData)
      console.log("🎯 เริ่มตรวจจับฟิลด์จาก OCR result...")

      // Extract form fields using multiple methods
      const fields = [
        ...this.extractFieldsFromText(ocrResult.text, ocrResult.words),
        ...this.extractFieldsFromLines(ocrResult.lines),
        ...this.extractFieldsFromStructure(ocrResult.blocks),
        ...this.extractFieldsFromTables(ocrResult.tables),
      ]

      // Remove duplicates and merge similar fields
      const uniqueFields = this.deduplicateFields(fields)

      console.log("🎯 ตรวจจับฟิลด์เสร็จสิ้น:", uniqueFields.length, "ฟิลด์")

      return {
        fields: uniqueFields,
        confidence: ocrResult.confidence,
        ocrText: ocrResult.text,
        method: "tesseract-comprehensive",
        statistics: ocrResult.statistics,
        detectedStructures: {
          forms: ocrResult.forms.length,
          tables: ocrResult.tables.length,
          textBlocks: ocrResult.blocks.length,
        },
      }
    } catch (error) {
      console.error("❌ Tesseract field detection error:", error)
      return { fields: [], confidence: 0.5 }
    }
  }

  private async base64ToImageElement(base64Data: string): Promise<HTMLImageElement> {
    return new Promise((resolve, reject) => {
      const img = new Image()
      img.onload = () => resolve(img)
      img.onerror = reject

      // Handle data URL or raw base64
      if (base64Data.startsWith("data:")) {
        img.src = base64Data
      } else {
        img.src = `data:image/png;base64,${base64Data}`
      }
    })
  }

  private cleanText(text: string): string {
    if (!text) return ""

    return text
      .replace(/\s+/g, " ") // Normalize whitespace
      .replace(/[^\u0000-\u007F\u0E00-\u0E7F\u1000-\u109F]/g, "") // Keep only ASCII, Thai, Myanmar
      .trim()
  }

  private extractBlocks(tesseractData: any): any[] {
    if (!tesseractData.blocks) return []

    return tesseractData.blocks
      .filter((block: any) => block.text?.trim())
      .map((block: any, index: number) => ({
        text: this.cleanText(block.text),
        confidence: (block.confidence || 80) / 100,
        bbox: this.normalizeBbox(block.bbox),
        blockIndex: index,
        type: this.classifyBlockType(block.text),
      }))
  }

  private extractWords(tesseractData: any): any[] {
    if (!tesseractData.words) return []

    return tesseractData.words
      .filter((word: any) => word.text?.trim())
      .map((word: any, index: number) => ({
        text: this.cleanText(word.text),
        confidence: (word.confidence || 80) / 100,
        bbox: this.normalizeBbox(word.bbox),
        wordIndex: index,
        language: this.detectLanguage(word.text),
      }))
  }

  private extractLines(tesseractData: any): any[] {
    if (!tesseractData.lines) return []

    return tesseractData.lines
      .filter((line: any) => line.text?.trim())
      .map((line: any, index: number) => ({
        text: this.cleanText(line.text),
        confidence: (line.confidence || 80) / 100,
        bbox: this.normalizeBbox(line.bbox),
        lineIndex: index,
        words: line.words?.length || 0,
      }))
  }

  private extractParagraphs(tesseractData: any): any[] {
    if (!tesseractData.paragraphs) return []

    return tesseractData.paragraphs
      .filter((para: any) => para.text?.trim())
      .map((para: any, index: number) => ({
        text: this.cleanText(para.text),
        confidence: (para.confidence || 80) / 100,
        bbox: this.normalizeBbox(para.bbox),
        paragraphIndex: index,
        lines: para.lines?.length || 0,
      }))
  }

  private normalizeBbox(bbox: any): any {
    if (!bbox) return { x: 0, y: 0, width: 0, height: 0 }

    return {
      x: bbox.x0 || 0,
      y: bbox.y0 || 0,
      width: (bbox.x1 || 0) - (bbox.x0 || 0),
      height: (bbox.y1 || 0) - (bbox.y0 || 0),
    }
  }

  private classifyBlockType(text: string): string {
    if (!text) return "unknown"

    const cleanText = text.toLowerCase().trim()

    if (/^[\d\s\-/.]+$/.test(cleanText)) return "number"
    if (/วันที่|date|ออกให้วันที่/.test(cleanText)) return "date"
    if (/ลายเซ็น|signature|sign/.test(cleanText)) return "signature"
    if (/ชื่อ|name|นาย|นาง|นางสาว/.test(cleanText)) return "name"
    if (/ที่อยู่|address|เลขที่/.test(cleanText)) return "address"
    if (/เบอร์|โทร|phone|tel/.test(cleanText)) return "phone"
    if (/อีเมล|email|@/.test(cleanText)) return "email"

    return "text"
  }

  private detectTables(tesseractData: any): any[] {
    // Simple table detection based on aligned text blocks
    const tables: any[] = []
    const blocks = tesseractData.blocks || []

    // Group blocks by Y position (rows)
    const rowGroups: any = {}
    blocks.forEach((block: any) => {
      if (!block.bbox) return
      const y = Math.round(block.bbox.y0 / 20) * 20 // Group by 20px intervals
      if (!rowGroups[y]) rowGroups[y] = []
      rowGroups[y].push(block)
    })

    // Find potential table rows (multiple blocks at same Y level)
    Object.keys(rowGroups).forEach((y) => {
      const row = rowGroups[y]
      if (row.length >= 2) {
        // Sort by X position
        row.sort((a: any, b: any) => (a.bbox?.x0 || 0) - (b.bbox?.x0 || 0))

        tables.push({
          type: "table_row",
          y: Number.parseInt(y),
          cells: row.map((block: any) => ({
            text: this.cleanText(block.text),
            bbox: this.normalizeBbox(block.bbox),
            confidence: (block.confidence || 80) / 100,
          })),
        })
      }
    })

    return tables
  }

  private detectFormStructure(tesseractData: any): any[] {
    const forms: any[] = []
    const text = tesseractData.text || ""

    // Detect form patterns
    const formPatterns = [
      { pattern: /แบบฟอร์ม|form|ใบสมัคร|application/i, type: "application_form" },
      { pattern: /บต\.?\s*\d+|wp\.?\s*\d+/i, type: "work_permit_form" },
      { pattern: /ใบอนุญาต|permit|license/i, type: "permit_form" },
      { pattern: /สัญญา|contract|agreement/i, type: "contract_form" },
    ]

    formPatterns.forEach((pattern) => {
      if (pattern.pattern.test(text)) {
        forms.push({
          type: pattern.type,
          confidence: 0.8,
          detected: true,
        })
      }
    })

    return forms
  }

  private extractFieldsFromText(text: string, words: any[]): any[] {
    const fields: any[] = []

    // Comprehensive Thai form field patterns
    const patterns = [
      {
        pattern: /ชื่อ[\s\-_]*(?:ผู้ยื่นคำขอ|ผู้ขอ|นาย|นาง|นางสาว|ผู้สมัคร)?[\s\-_]*:?[\s\-_]*([^\n\r]+)?/gi,
        name: "ชื่อผู้ยื่นคำขอ",
        type: "text",
        required: true,
      },
      {
        pattern: /สัญชาติ[\s\-_]*:?[\s\-_]*([^\n\r]+)?/gi,
        name: "สัญชาติ",
        type: "text",
        required: true,
      },
      {
        pattern: /(?:เลขที่|หมายเลข)[\s\-_]*(?:ใบอนุญาต|ใบอนุญาตทำงาน|work\s*permit)?[\s\-_]*:?[\s\-_]*([^\n\r]+)?/gi,
        name: "เลขที่ใบอนุญาตทำงาน",
        type: "text",
        required: true,
      },
      {
        pattern: /วันที่[\s\-_]*(?:ออก|ออกใบอนุญาต|issue)?[\s\-_]*:?[\s\-_]*([^\n\r]+)?/gi,
        name: "วันที่ออกใบอนุญาต",
        type: "date",
        required: true,
      },
      {
        pattern: /(?:ใช้ได้ถึง|valid\s*until)[\s\-_]*:?[\s\-_]*([^\n\r]+)?/gi,
        name: "วันที่หมดอายุ",
        type: "date",
        required: true,
      },
      {
        pattern: /ที่อยู่[\s\-_]*(?:ในประเทศไทย|สถานประกอบการ|บริษัท|ห้างร้าน)?[\s\-_]*:?[\s\-_]*([^\n\r]+)?/gi,
        name: "ที่อยู่",
        type: "text",
        required: false,
      },
      {
        pattern: /ชื่อนายจ้าง[\s\-_]*:?[\s\-_]*([^\n\r]+)?/gi,
        name: "ชื่อนายจ้าง",
        type: "text",
        required: true,
      },
      {
        pattern: /(?:จังหวัด|province)[\s\-_]*:?[\s\-_]*([^\n\r]+)?/gi,
        name: "จังหวัด",
        type: "text",
        required: false,
      },
      {
        pattern: /(?:รหัสไปรษณีย์|postal\s*code)[\s\-_]*:?[\s\-_]*([^\n\r]+)?/gi,
        name: "รหัสไปรษณีย์",
        type: "text",
        required: false,
      },
      {
        pattern: /(?:โทรศัพท์|telephone|phone)[\s\-_]*:?[\s\-_]*([^\n\r]+)?/gi,
        name: "โทรศัพท์",
        type: "text",
        required: false,
      },
      {
        pattern: /ลายเซ็น[\s\-_]*(?:ผู้ยื่นคำขอ|ผู้ขอ|ผู้สมัคร)?[\s\-_]*:?[\s\-_]*$/gi,
        name: "ลายเซ็นผู้ยื่นคำขอ",
        type: "signature",
        required: true,
      },
    ]

    let yPosition = 100
    patterns.forEach((pattern, index) => {
      let match
      while ((match = pattern.pattern.exec(text)) !== null) {
        // Try to find position from words data
        const matchingWord = words.find((word) => {
          return word.text && new RegExp(pattern.pattern.source.split("\\s")[0], "i").test(word.text)
        })

        const extractedValue = match[1]?.trim() || ""

        fields.push({
          id: `tesseract-field-${index}-${fields.length}`,
          name: pattern.name,
          type: pattern.type,
          x: matchingWord?.bbox?.x || 150,
          y: matchingWord?.bbox?.y || yPosition,
          width: pattern.type === "signature" ? 200 : Math.max(180, extractedValue.length * 8),
          height: pattern.type === "signature" ? 50 : 25,
          page: 1,
          confidence: 0.8,
          required: pattern.required,
          detectionMethod: "tesseract",
          value: extractedValue,
          rawMatch: match[0],
        })

        yPosition += pattern.type === "signature" ? 70 : 40
      }
    })

    return fields
  }

  private extractFieldsFromLines(lines: any[]): any[] {
    const fields: any[] = []

    lines.forEach((line, index) => {
      const text = line.text?.trim()
      if (!text) return

      // Look for colon-separated key-value pairs
      const colonMatch = text.match(/^([^:]+):(.*)$/)
      if (colonMatch) {
        const label = colonMatch[1].trim()
        const value = colonMatch[2].trim()

        if (label.length > 2 && label.length < 50) {
          fields.push({
            id: `tesseract-line-${index}`,
            name: label,
            type: this.inferFieldType(label, value),
            x: line.bbox?.x || 100,
            y: line.bbox?.y || 100 + index * 30,
            width: Math.max(150, value.length * 8),
            height: 25,
            page: 1,
            confidence: line.confidence || 0.7,
            required: this.isRequiredField(label),
            detectionMethod: "tesseract-line",
            value: value,
          })
        }
      }
    })

    return fields
  }

  private extractFieldsFromStructure(blocks: any[]): any[] {
    const fields: any[] = []

    // Look for checkbox patterns
    blocks.forEach((block, index) => {
      const text = block.text?.trim()
      if (!text) return

      // Detect checkbox patterns
      if (/☐|☑|□|■|\[\s*\]|\[x\]|\[X\]/g.test(text)) {
        const cleanLabel = text.replace(/☐|☑|□|■|\[\s*\]|\[x\]|\[X\]/g, "").trim()

        if (cleanLabel.length > 2) {
          fields.push({
            id: `tesseract-checkbox-${index}`,
            name: cleanLabel,
            type: "checkbox",
            x: block.bbox?.x || 100,
            y: block.bbox?.y || 100,
            width: 20,
            height: 20,
            page: 1,
            confidence: block.confidence || 0.7,
            required: false,
            detectionMethod: "tesseract-structure",
            value: /☑|■|\[x\]|\[X\]/.test(text) ? "checked" : "unchecked",
          })
        }
      }
    })

    return fields
  }

  private extractFieldsFromTables(tables: any[]): any[] {
    const fields: any[] = []

    tables.forEach((table, tableIndex) => {
      if (table.type === "table_row" && table.cells) {
        table.cells.forEach((cell: any, cellIndex: number) => {
          if (cell.text?.trim()) {
            fields.push({
              id: `tesseract-table-${tableIndex}-${cellIndex}`,
              name: `ตาราง ${tableIndex + 1} คอลัมน์ ${cellIndex + 1}`,
              type: "text",
              x: cell.bbox?.x || 100,
              y: cell.bbox?.y || 100,
              width: cell.bbox?.width || 100,
              height: cell.bbox?.height || 25,
              page: 1,
              confidence: cell.confidence || 0.7,
              required: false,
              detectionMethod: "tesseract-table",
              value: cell.text,
            })
          }
        })
      }
    })

    return fields
  }

  private inferFieldType(label: string, value: string): string {
    const lowerLabel = label.toLowerCase()
    const lowerValue = value.toLowerCase()

    if (/วันที่|date|ออกให้วันที่/.test(lowerLabel)) return "date"
    if (/ลายเซ็น|signature|sign/.test(lowerLabel)) return "signature"
    if (/เบอร์|โทร|phone|tel/.test(lowerLabel)) return "phone"
    if (/อีเมล|email/.test(lowerLabel)) return "email"
    if (/^\d+$/.test(value)) return "number"

    return "text"
  }

  private deduplicateFields(fields: any[]): any[] {
    const unique: any[] = []
    const threshold = 30 // Distance threshold for considering fields as duplicates

    for (const field of fields) {
      const existing = unique.find((existing) => {
        const distance = Math.sqrt(Math.pow(existing.x - field.x, 2) + Math.pow(existing.y - field.y, 2))
        const nameMatch =
          existing.name.toLowerCase().includes(field.name.toLowerCase().substring(0, 5)) ||
          field.name.toLowerCase().includes(existing.name.toLowerCase().substring(0, 5))
        return distance < threshold && nameMatch
      })

      if (existing) {
        // Keep the field with higher confidence or more complete data
        if (field.confidence > existing.confidence || (field.value && !existing.value)) {
          const index = unique.indexOf(existing)
          unique[index] = { ...existing, ...field, confidence: Math.max(existing.confidence, field.confidence) }
        }
      } else {
        unique.push(field)
      }
    }

    return unique
  }

  private detectLanguage(text: string): string {
    if (!text) return "unknown"

    const thaiPattern = /[\u0E00-\u0E7F]/
    const myanmarPattern = /[\u1000-\u109F]/
    const englishPattern = /[a-zA-Z]/

    const thaiCount = (text.match(thaiPattern) || []).length
    const myanmarCount = (text.match(myanmarPattern) || []).length
    const englishCount = (text.match(englishPattern) || []).length

    if (thaiCount > myanmarCount && thaiCount > englishCount) return "th"
    if (myanmarCount > thaiCount && myanmarCount > englishCount) return "my"
    if (englishCount > thaiCount && englishCount > myanmarCount) return "en"

    return "mixed"
  }

  private calculateAverageConfidence(tesseractData: any): number {
    const words = tesseractData.words || []
    if (words.length === 0) return 0

    const totalConfidence = words.reduce((sum: number, word: any) => sum + (word.confidence || 0), 0)
    return Math.round((totalConfidence / words.length) * 100) / 100
  }

  private isRequiredField(fieldName: string): boolean {
    const requiredFields = ["ชื่อผู้ยื่นคำขอ", "สัญชาติ", "เลขที่ใบอนุญาตทำงาน", "วันที่ออกใบอนุญาต", "ลายเซ็นผู้ยื่นคำขอ", "ชื่อนายจ้าง"]
    return requiredFields.some((required) => fieldName.toLowerCase().includes(required.toLowerCase()))
  }

  async terminate(): Promise<void> {
    if (this.worker) {
      await this.worker.terminate()
      this.worker = null
      this.isInitialized = false
      console.log("🔧 Tesseract.js terminated")
    }
  }

  // Test Tesseract connection with actual OCR
  async testConnection(): Promise<{ success: boolean; message: string; features?: string[] }> {
    try {
      console.log("🧪 ทดสอบ Tesseract.js...")

      await this.initialize()

      // Create a simple test image with Thai text
      const testImage = this.createTestImage()
      const testResult = await this.performOCR(testImage)

      return {
        success: true,
        message: `Tesseract.js พร้อมใช้งาน! ตรวจพบข้อความ ${testResult.statistics.totalWords} คำ`,
        features: [
          "Thai OCR (ภาษาไทย)",
          "English OCR (ภาษาอังกฤษ)",
          "Myanmar OCR (ภาษาพม่า)",
          "Comprehensive Text Extraction",
          "Form Field Detection",
          "Table Detection",
          "Offline Processing",
          "No API Key Required",
        ],
      }
    } catch (error) {
      return {
        success: false,
        message: `Tesseract.js ไม่สามารถใช้งานได้: ${error instanceof Error ? error.message : "Unknown error"}`,
      }
    }
  }

  private createTestImage(): string {
    // Create a simple canvas with Thai text for testing
    const canvas = document.createElement("canvas")
    canvas.width = 400
    canvas.height = 100
    const ctx = canvas.getContext("2d")!

    ctx.fillStyle = "white"
    ctx.fillRect(0, 0, 400, 100)
    ctx.fillStyle = "black"
    ctx.font = "16px Arial"
    ctx.fillText("ทดสอบ Tesseract.js", 20, 40)
    ctx.fillText("Test Tesseract.js", 20, 70)

    return canvas.toDataURL()
  }
}

// Export singleton instance
export const tesseractClient = new TesseractClient()
