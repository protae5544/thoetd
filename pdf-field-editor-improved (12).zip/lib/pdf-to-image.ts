"use client"

// Convert PDF to image for AI analysis
export class PDFToImageConverter {
  async convertPDFToImage(file: File, pageNumber = 1): Promise<string> {
    try {
      // Use PDF.js to convert PDF to image
      const pdfjsLib = await import("pdfjs-dist")
      pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/4.0.379/pdf.worker.min.js`

      const arrayBuffer = await file.arrayBuffer()
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise
      const page = await pdf.getPage(pageNumber)

      const viewport = page.getViewport({ scale: 2.0 })
      const canvas = document.createElement("canvas")
      const context = canvas.getContext("2d")!

      canvas.height = viewport.height
      canvas.width = viewport.width

      await page.render({
        canvasContext: context,
        viewport: viewport,
      }).promise

      // Convert canvas to base64 image
      return canvas.toDataURL("image/jpeg", 0.8).split(",")[1]
    } catch (error) {
      console.error("PDF to image conversion error:", error)
      throw new Error("ไม่สามารถแปลง PDF เป็นรูปภาพได้")
    }
  }

  async convertAllPages(file: File): Promise<string[]> {
    try {
      const pdfjsLib = await import("pdfjs-dist")
      pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/4.0.379/pdf.worker.min.js`

      const arrayBuffer = await file.arrayBuffer()
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise

      const images: string[] = []
      for (let i = 1; i <= pdf.numPages; i++) {
        const imageData = await this.convertPDFToImage(file, i)
        images.push(imageData)
      }

      return images
    } catch (error) {
      console.error("PDF conversion error:", error)
      throw new Error("ไม่สามารถแปลง PDF ได้")
    }
  }
}

export const pdfToImageConverter = new PDFToImageConverter()
