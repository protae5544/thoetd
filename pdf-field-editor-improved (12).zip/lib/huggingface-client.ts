"use client"

// Hugging Face Space OCR Client for Typhoon OCR
export class HuggingFaceClient {
  private spaceUrl: string
  private apiUrl: string

  constructor(spaceUrl = "https://protae5544-typhoon-ocr.hf.space") {
    this.spaceUrl = spaceUrl
    this.apiUrl = `${spaceUrl}/api/predict`
  }

  async performOCR(imageData: string): Promise<any> {
    try {
      console.log("🚀 เรียกใช้ Hugging Face Space OCR...")

      // Convert base64 to blob for Gradio
      const response = await fetch(this.apiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          data: [imageData], // Gradio expects data array
          fn_index: 0, // Usually the first function
        }),
      })

      if (!response.ok) {
        throw new Error(`HF Space API error: ${response.status}`)
      }

      const result = await response.json()
      console.log("✅ HF Space OCR สำเร็จ:", result)

      return this.processOCRResponse(result)
    } catch (error) {
      console.error("❌ HF Space OCR error:", error)
      // Fallback to mock data
      return this.getMockOCRResult()
    }
  }

  async detectFormFields(imageData: string): Promise<any> {
    try {
      console.log("🔍 ตรวจจับฟิลด์ด้วย HF Space...")

      const response = await fetch(this.apiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          data: [imageData, "detect_fields"], // Add mode parameter
          fn_index: 1, // Field detection function
        }),
      })

      if (!response.ok) {
        throw new Error(`HF Space API error: ${response.status}`)
      }

      const result = await response.json()
      return this.extractFormFields(result)
    } catch (error) {
      console.error("❌ HF Space field detection error:", error)
      return { fields: [], confidence: 0.5 }
    }
  }

  private processOCRResponse(data: any): any {
    // Process Gradio response format
    const ocrResult = data.data?.[0] || data.data || ""

    return {
      text: typeof ocrResult === "string" ? ocrResult : ocrResult.text || "",
      confidence: 0.85,
      blocks: this.parseTextToBlocks(ocrResult),
      words: [],
      tables: [],
      forms: [],
      language: "th",
      provider: "huggingface-space",
    }
  }

  private parseTextToBlocks(text: string): any[] {
    if (typeof text !== "string") return []

    const lines = text.split("\n").filter((line) => line.trim())
    return lines.map((line, index) => ({
      text: line.trim(),
      confidence: 0.85,
      bbox: {
        x: 50,
        y: 50 + index * 30,
        width: 400,
        height: 25,
      },
    }))
  }

  private extractFormFields(data: any): any {
    const fields: any[] = []
    const ocrText = data.data?.[0] || ""

    // Pattern-based field detection from OCR text
    const patterns = [
      {
        pattern: /ชื่อ[\s\-_]*(?:ผู้ยื่นคำขอ|ผู้ขอ|นาย|นาง|นางสาว)?[\s\-_]*:?[\s\-_]*(.+)?/i,
        name: "ชื่อผู้ยื่นคำขอ",
        type: "text",
      },
      {
        pattern: /สัญชาติ[\s\-_]*:?[\s\-_]*(.+)?/i,
        name: "สัญชาติ",
        type: "text",
      },
      {
        pattern: /เลขที่[\s\-_]*(?:ใบอนุญาต|ใบอนุญาตทำงาน)?[\s\-_]*:?[\s\-_]*(.+)?/i,
        name: "เลขที่ใบอนุญาตทำงาน",
        type: "text",
      },
      {
        pattern: /วันที่[\s\-_]*(?:ออก|ออกใบอนุญาต)?[\s\-_]*:?[\s\-_]*(.+)?/i,
        name: "วันที่ออกใบอนุญาต",
        type: "date",
      },
      {
        pattern: /ที่อยู่[\s\-_]*(?:สถานประกอบการ|บริษัท|ห้างร้าน)?[\s\-_]*:?[\s\-_]*(.+)?/i,
        name: "ที่อยู่สถานประกอบการ",
        type: "text",
      },
      {
        pattern: /ลายเซ็น[\s\-_]*(?:ผู้ยื่นคำขอ|ผู้ขอ)?[\s\-_]*:?[\s\-_]*$/i,
        name: "ลายเซ็นผู้ยื่นคำขอ",
        type: "signature",
      },
    ]

    let yPosition = 100
    patterns.forEach((pattern, index) => {
      const match = ocrText.match(pattern.pattern)
      if (match) {
        fields.push({
          id: `hf-field-${index}`,
          name: pattern.name,
          type: pattern.type,
          x: 150,
          y: yPosition,
          width: pattern.type === "signature" ? 200 : 180,
          height: pattern.type === "signature" ? 50 : 25,
          page: 1,
          confidence: 0.8,
          required: this.isRequiredField(pattern.name),
          detectionMethod: "huggingface-space",
          value: match[1]?.trim() || "", // Extract captured value
        })
        yPosition += pattern.type === "signature" ? 70 : 40
      }
    })

    return {
      fields: fields,
      confidence: 0.8,
      ocrText: ocrText,
    }
  }

  private isRequiredField(fieldName: string): boolean {
    const requiredFields = ["ชื่อผู้ยื่นคำขอ", "สัญชาติ", "เลขที่ใบอนุญาตทำงาน", "วันที่ออกใบอนุญาต", "ลายเซ็นผู้ยื่นคำขอ"]
    return requiredFields.some((required) => fieldName.includes(required))
  }

  private getMockOCRResult(): any {
    return {
      text: `คำขอเปลี่ยนรายการในใบอนุญาตทำงาน
      
ชื่อผู้ยื่นคำขอ: _________________
สัญชาติ: _________________
เลขที่ใบอนุญาตทำงาน: _________________
วันที่ออกใบอนุญาต: _________________
ที่อยู่สถานประกอบการ: _________________
ประเภทกิจการ: _________________

ลายเซ็นผู้ยื่นคำขอ: _________________`,
      confidence: 0.85,
      blocks: [],
      words: [],
      tables: [],
      forms: [],
      language: "th",
      provider: "huggingface-space-mock",
    }
  }

  // Test HF Space connection
  async testConnection(): Promise<{ success: boolean; message: string; spaceUrl?: string }> {
    try {
      console.log("🧪 ทดสอบการเชื่อมต่อ HF Space...")

      // Test with simple text
      const testImage =
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/5+hHgAHggJ/PchI7wAAAABJRU5ErkJggg=="

      const response = await fetch(this.apiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          data: [testImage],
          fn_index: 0,
        }),
      })

      if (response.ok) {
        const result = await response.json()
        return {
          success: true,
          message: "เชื่อมต่อ Hugging Face Space สำเร็จ! 🎉",
          spaceUrl: this.spaceUrl,
        }
      } else {
        return {
          success: false,
          message: `HF Space Error: ${response.status} - กรุณาตรวจสอบว่า Space ทำงานอยู่`,
          spaceUrl: this.spaceUrl,
        }
      }
    } catch (error) {
      return {
        success: false,
        message: `การเชื่อมต่อล้มเหลว: ${error instanceof Error ? error.message : "Unknown error"}`,
        spaceUrl: this.spaceUrl,
      }
    }
  }

  // Alternative API endpoints for different Gradio setups
  async tryAlternativeEndpoints(imageData: string): Promise<any> {
    const endpoints = [
      `${this.spaceUrl}/api/predict`,
      `${this.spaceUrl}/gradio_api/call/predict`,
      `${this.spaceUrl}/call/predict`,
    ]

    for (const endpoint of endpoints) {
      try {
        console.log(`🔄 ลอง endpoint: ${endpoint}`)

        const response = await fetch(endpoint, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            data: [imageData],
            fn_index: 0,
          }),
        })

        if (response.ok) {
          const result = await response.json()
          console.log(`✅ สำเร็จที่ endpoint: ${endpoint}`)
          this.apiUrl = endpoint // Update successful endpoint
          return this.processOCRResponse(result)
        }
      } catch (error) {
        console.warn(`⚠️ ล้มเหลวที่ endpoint: ${endpoint}`, error)
        continue
      }
    }

    throw new Error("ไม่สามารถเชื่อมต่อ HF Space ได้ทุก endpoint")
  }
}

// Export singleton instance
export const huggingFaceClient = new HuggingFaceClient("https://protae5544-typhoon-ocr.hf.space")
