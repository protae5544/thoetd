"use client"

// OpenTyphoon AI OCR Client for Thai text recognition
export class OpenTyphoonClient {
  private apiKey: string
  private baseUrl = "https://api.opentyphoon.ai/v1"

  constructor(apiKey: string) {
    this.apiKey = apiKey
  }

  async performOCR(imageData: string): Promise<any> {
    if (!this.apiKey || this.apiKey === "demo-key") {
      // Return mock data if no API key
      return this.getMockOCRResult()
    }

    try {
      const response = await fetch(`${this.baseUrl}/ocr`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${this.apiKey}`,
        },
        body: JSON.stringify({
          model: "typhoon-ocr",
          image: imageData,
          language: "th", // Thai language
          output_format: "json",
          extract_tables: true,
          extract_forms: true,
        }),
      })

      if (!response.ok) {
        throw new Error(`OpenTyphoon API error: ${response.status}`)
      }

      const data = await response.json()
      return this.processOCRResponse(data)
    } catch (error) {
      console.error("OpenTyphoon OCR error:", error)
      // Fallback to mock data
      return this.getMockOCRResult()
    }
  }

  async detectFormFields(imageData: string): Promise<any> {
    try {
      const response = await fetch(`${this.baseUrl}/ocr`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${this.apiKey}`,
        },
        body: JSON.stringify({
          model: "typhoon-ocr",
          image: imageData,
          language: "th",
          output_format: "json",
          extract_forms: true,
          detect_fields: true,
          field_types: ["text", "number", "date", "checkbox", "signature"],
        }),
      })

      if (!response.ok) {
        throw new Error(`OpenTyphoon API error: ${response.status}`)
      }

      const data = await response.json()
      return this.extractFormFields(data)
    } catch (error) {
      console.error("OpenTyphoon form detection error:", error)
      return { fields: [], confidence: 0.5 }
    }
  }

  private processOCRResponse(data: any): any {
    return {
      text: data.text || "",
      confidence: data.confidence || 0.85,
      blocks: data.blocks || [],
      words: data.words || [],
      tables: data.tables || [],
      forms: data.forms || [],
      language: "th",
      provider: "opentyphoon",
    }
  }

  private extractFormFields(data: any): any {
    const fields: any[] = []

    // Process detected form fields
    if (data.forms && data.forms.length > 0) {
      data.forms.forEach((form: any, formIndex: number) => {
        if (form.fields) {
          form.fields.forEach((field: any, fieldIndex: number) => {
            fields.push({
              id: `typhoon-field-${formIndex}-${fieldIndex}`,
              name: this.translateFieldName(field.label || field.name || `ฟิลด์ ${fieldIndex + 1}`),
              type: this.mapFieldType(field.type || "text"),
              x: field.bbox?.x || 0,
              y: field.bbox?.y || 0,
              width: field.bbox?.width || 150,
              height: field.bbox?.height || 25,
              page: 1,
              confidence: field.confidence || 0.8,
              required: this.isRequiredField(field.label || field.name || ""),
              detectionMethod: "opentyphoon",
            })
          })
        }
      })
    }

    // Process text blocks for additional field detection
    if (data.blocks) {
      data.blocks.forEach((block: any, blockIndex: number) => {
        const text = block.text || ""
        const fieldPattern = this.detectFieldPattern(text)

        if (fieldPattern) {
          fields.push({
            id: `typhoon-pattern-${blockIndex}`,
            name: fieldPattern.name,
            type: fieldPattern.type,
            x: block.bbox?.x || 0,
            y: (block.bbox?.y || 0) + (block.bbox?.height || 0) + 5,
            width: Math.max(150, block.bbox?.width || 150),
            height: fieldPattern.type === "signature" ? 50 : 25,
            page: 1,
            confidence: 0.75,
            required: this.isRequiredField(fieldPattern.name),
            detectionMethod: "opentyphoon-pattern",
          })
        }
      })
    }

    return {
      fields: this.deduplicateFields(fields),
      confidence: 0.85,
      ocrText: data.text || "",
    }
  }

  private translateFieldName(name: string): string {
    const translations: Record<string, string> = {
      name: "ชื่อ",
      full_name: "ชื่อเต็ม",
      first_name: "ชื่อ",
      last_name: "นามสกุล",
      nationality: "สัญชาติ",
      id_number: "เลขบัตรประชาชน",
      passport: "หนังสือเดินทาง",
      work_permit: "ใบอนุญาตทำงาน",
      date: "วันที่",
      birth_date: "วันเกิด",
      issue_date: "วันที่ออก",
      expiry_date: "วันหมดอายุ",
      address: "ที่อยู่",
      phone: "เบอร์โทรศัพท์",
      email: "อีเมล",
      signature: "ลายเซ็น",
      employer: "นายจ้าง",
      company: "บริษัท",
      position: "ตำแหน่ง",
      salary: "เงินเดือน",
    }

    const lowerName = name.toLowerCase()
    for (const [key, value] of Object.entries(translations)) {
      if (lowerName.includes(key)) {
        return value
      }
    }

    return name
  }

  private mapFieldType(type: string): string {
    const typeMap: Record<string, string> = {
      text: "text",
      number: "number",
      date: "date",
      checkbox: "checkbox",
      signature: "signature",
      email: "text",
      phone: "text",
      currency: "number",
    }

    return typeMap[type.toLowerCase()] || "text"
  }

  private detectFieldPattern(text: string): { name: string; type: string } | null {
    const patterns = [
      {
        pattern: /ชื่อ[\s\-_]*(?:ผู้ยื่นคำขอ|ผู้ขอ|นาย|นาง|นางสาว)?[\s\-_]*:?[\s\-_]*$/i,
        name: "ชื่อผู้ยื่นคำขอ",
        type: "text",
      },
      {
        pattern: /สัญชาติ[\s\-_]*:?[\s\-_]*$/i,
        name: "สัญชาติ",
        type: "text",
      },
      {
        pattern: /เลขที่[\s\-_]*(?:ใบอนุญาต|ใบอนุญาตทำงาน)?[\s\-_]*:?[\s\-_]*$/i,
        name: "เลขที่ใบอนุญาตทำงาน",
        type: "text",
      },
      {
        pattern: /วันที่[\s\-_]*(?:ออก|ออกใบอนุญาต)?[\s\-_]*:?[\s\-_]*$/i,
        name: "วันที่ออกใบอนุญาต",
        type: "date",
      },
      {
        pattern: /ที่อยู่[\s\-_]*(?:สถานประกอบการ|บริษัท|ห้างร้าน)?[\s\-_]*:?[\s\-_]*$/i,
        name: "ที่อยู่สถานประกอบการ",
        type: "text",
      },
      {
        pattern: /ประเภท[\s\-_]*(?:กิจการ|ธุรกิจ|งาน)?[\s\-_]*:?[\s\-_]*$/i,
        name: "ประเภทกิจการ",
        type: "text",
      },
      {
        pattern: /ลายเซ็น[\s\-_]*(?:ผู้ยื่นคำขอ|ผู้ขอ)?[\s\-_]*:?[\s\-_]*$/i,
        name: "ลายเซ็นผู้ยื่นคำขอ",
        type: "signature",
      },
    ]

    for (const pattern of patterns) {
      if (pattern.pattern.test(text)) {
        return { name: pattern.name, type: pattern.type }
      }
    }

    return null
  }

  private isRequiredField(fieldName: string): boolean {
    const requiredFields = ["ชื่อผู้ยื่นคำขอ", "สัญชาติ", "เลขที่ใบอนุญาตทำงาน", "วันที่ออกใบอนุญาต", "ลายเซ็นผู้ยื่นคำขอ"]
    return requiredFields.some((required) => fieldName.includes(required))
  }

  private deduplicateFields(fields: any[]): any[] {
    const unique: any[] = []
    const threshold = 50 // Distance threshold for considering fields as duplicates

    for (const field of fields) {
      const existing = unique.find((existing) => {
        const distance = Math.sqrt(Math.pow(existing.x - field.x, 2) + Math.pow(existing.y - field.y, 2))
        return distance < threshold && existing.name.includes(field.name.substring(0, 5))
      })

      if (existing) {
        // Keep the field with higher confidence
        if (field.confidence > existing.confidence) {
          const index = unique.indexOf(existing)
          unique[index] = field
        }
      } else {
        unique.push(field)
      }
    }

    return unique
  }

  private getMockOCRResult(): any {
    return {
      text: `คำขอเปลี่ยนรายการในใบอนุญาตทำงาน
      
ชื่อผู้ยื่นคำขอ: _________________
สัญชาติ: _________________
เลขที่ใบอนุญาตทำงาน: _________________
วันที่ออกใบอนุญาต: _________________
ที่อยู่สถานประกอบการ: _________________
ประเภทกิจการ: _________________

ลายเซ็นผู้ยื่นคำขอ: _________________`,
      confidence: 0.85,
      blocks: [],
      words: [],
      tables: [],
      forms: [],
      language: "th",
      provider: "opentyphoon-mock",
    }
  }

  // Test API connection
  async testConnection(): Promise<{ success: boolean; message: string }> {
    if (!this.apiKey || this.apiKey === "demo-key") {
      return {
        success: false,
        message: "ไม่พบ OpenTyphoon API Key กรุณาตั้งค่า NEXT_PUBLIC_OPENTYPHOON_API_KEY",
      }
    }

    try {
      // Test with a simple image (1x1 pixel white PNG)
      const testImage =
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/5+hHgAHggJ/PchI7wAAAABJRU5ErkJggg=="

      const response = await fetch(`${this.baseUrl}/ocr`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${this.apiKey}`,
        },
        body: JSON.stringify({
          model: "typhoon-ocr",
          image: testImage,
          language: "th",
        }),
      })

      if (response.ok) {
        return {
          success: true,
          message: "เชื่อมต่อ OpenTyphoon API สำเร็จ",
        }
      } else {
        const errorData = await response.json().catch(() => ({}))
        return {
          success: false,
          message: `OpenTyphoon API Error: ${response.status} - ${errorData.error?.message || "กรุณาตรวจสอบ API Key"}`,
        }
      }
    } catch (error) {
      return {
        success: false,
        message: `การเชื่อมต่อล้มเหลว: ${error instanceof Error ? error.message : "Unknown error"}`,
      }
    }
  }
}

// Export singleton instance
export const openTyphoonClient = new OpenTyphoonClient(process.env.NEXT_PUBLIC_OPENTYPHOON_API_KEY || "demo-key")
