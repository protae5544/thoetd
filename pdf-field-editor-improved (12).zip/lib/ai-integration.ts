"use client"

export interface AIFieldDetectionRequest {
  documentType: string
  ocrText: string
  imageData?: string // Base64 encoded image
}

export interface AIFieldDetectionResponse {
  fields: DetectedField[]
  confidence: number
  suggestions: string[]
}

export interface DetectedField {
  id: string
  name: string
  type: "text" | "number" | "date" | "checkbox" | "signature"
  x: number
  y: number
  width: number
  height: number
  page: number
  confidence: number
  required: boolean
  format?: string
}

export class AIFieldDetector {
  private apiKey: string
  private baseUrl: string

  constructor(apiKey: string, provider: "openai" | "claude" = "openai") {
    this.apiKey = apiKey
    this.baseUrl = provider === "openai" ? "https://api.openai.com/v1" : "https://api.anthropic.com/v1"
  }

  async detectFields(request: AIFieldDetectionRequest): Promise<AIFieldDetectionResponse> {
    try {
      const systemPrompt = this.getSystemPrompt(request.documentType)

      // Mock response for now - replace with actual API call
      const mockResponse: AIFieldDetectionResponse = {
        fields: this.generateMockFields(request.documentType),
        confidence: 0.87,
        suggestions: ["ตรวจพบฟิลด์ที่อาจต้องการการยืนยัน", "แนะนำให้ตรวจสอบตำแหน่งฟิลด์วันที่", "พบฟิลด์ลายเซ็นที่อาจต้องปรับขนาด"],
      }

      return mockResponse
    } catch (error) {
      console.error("AI field detection error:", error)
      throw new Error("Failed to detect fields using AI")
    }
  }

  private getSystemPrompt(documentType: string): string {
    const prompts: Record<string, string> = {
      "work-permit-change": `
        You are an expert at analyzing Thai work permit change request forms (แบบ บต.44).
        Identify all fillable fields including:
        - Personal information fields (name, nationality, etc.)
        - Work permit details (number, issue date, etc.)
        - Address information
        - Signature areas
        
        Return precise coordinates and field types in JSON format.
      `,
      "employment-cert": `
        You are an expert at analyzing Thai employment certification forms (แบบ บต.46).
        Identify all fillable fields including:
        - Employer information
        - Employee details
        - Job description fields
        - Financial information
        - Signature areas
        
        Return precise coordinates and field types in JSON format.
      `,
      default: `
        You are an expert at detecting form fields in Thai government documents.
        Analyze the document and identify all fillable fields with high accuracy.
        Return the results in JSON format with field positions, types, and confidence scores.
      `,
    }

    return prompts[documentType] || prompts["default"]
  }

  private generateMockFields(documentType: string): DetectedField[] {
    const fieldTemplates: Record<string, DetectedField[]> = {
      "work-permit-change": [
        {
          id: "wp-name",
          name: "ชื่อผู้ยื่นคำขอ",
          type: "text",
          x: 150,
          y: 120,
          width: 200,
          height: 20,
          page: 1,
          confidence: 0.92,
          required: true,
        },
        {
          id: "wp-nationality",
          name: "สัญชาติ",
          type: "text",
          x: 100,
          y: 150,
          width: 150,
          height: 20,
          page: 1,
          confidence: 0.88,
          required: true,
        },
        {
          id: "wp-permit-number",
          name: "เลขที่ใบอนุญาตทำงาน",
          type: "text",
          x: 200,
          y: 180,
          width: 180,
          height: 20,
          page: 1,
          confidence: 0.85,
          required: true,
        },
        {
          id: "wp-issue-date",
          name: "วันที่ออกใบอนุญาต",
          type: "date",
          x: 150,
          y: 210,
          width: 120,
          height: 20,
          page: 1,
          confidence: 0.9,
          required: true,
          format: "DD/MM/YYYY",
        },
      ],
      "employment-cert": [
        {
          id: "emp-employer-name",
          name: "ชื่อนายจ้าง",
          type: "text",
          x: 120,
          y: 200,
          width: 250,
          height: 20,
          page: 1,
          confidence: 0.94,
          required: true,
        },
        {
          id: "emp-address",
          name: "ที่อยู่สถานประกอบการ",
          type: "text",
          x: 100,
          y: 230,
          width: 300,
          height: 40,
          page: 1,
          confidence: 0.89,
          required: true,
        },
        {
          id: "emp-business-type",
          name: "ประเภทกิจการ",
          type: "text",
          x: 150,
          y: 280,
          width: 200,
          height: 20,
          page: 1,
          confidence: 0.86,
          required: true,
        },
      ],
    }

    return fieldTemplates[documentType] || []
  }
}

// Export singleton instance
export const aiFieldDetector = new AIFieldDetector(process.env.NEXT_PUBLIC_OPENAI_API_KEY || "demo-key")
