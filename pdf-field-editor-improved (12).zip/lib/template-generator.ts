"use client"

export interface TemplateField {
  id: string
  name: string
  type: string
  required: boolean
  format?: string
  position: {
    x: number
    y: number
    width: number
    height: number
    page: number
  }
}

export interface DocumentTemplate {
  documentType: string
  documentName: string
  fields: TemplateField[]
  metadata: {
    confidence: number
    pages: number
    processedAt: string
    version: string
  }
}

export class TemplateGenerator {
  static generateJSONTemplate(document: any): DocumentTemplate {
    return {
      documentType: document.type,
      documentName: document.name,
      fields: document.fields.map((field: any) => ({
        id: field.id,
        name: field.name,
        type: field.type,
        required: field.required,
        format: field.format,
        position: {
          x: field.x,
          y: field.y,
          width: field.width,
          height: field.height,
          page: field.page,
        },
      })),
      metadata: {
        confidence: document.confidence,
        pages: document.pages || 1,
        processedAt: new Date().toISOString(),
        version: "1.0.0",
      },
    }
  }

  static generateCSVTemplate(document: any): string {
    const headers = document.fields.map((field: any) => field.name)
    const csvHeaders = headers.join(",")
    const emptyRow = headers.map(() => "").join(",")

    return `${csvHeaders}\n${emptyRow}`
  }

  static generateDataMappingTemplate(document: any): any {
    return {
      documentId: document.id,
      documentType: document.type,
      fieldMapping: document.fields.reduce((mapping: any, field: any) => {
        mapping[field.id] = {
          fieldName: field.name,
          dataType: field.type,
          required: field.required,
          validation: this.getValidationRules(field),
          defaultValue: "",
        }
        return mapping
      }, {}),
      processingRules: {
        dateFormat: "DD/MM/YYYY",
        numberFormat: "0.00",
        textEncoding: "UTF-8",
      },
    }
  }

  private static getValidationRules(field: any): any {
    const rules: any = {}

    switch (field.type) {
      case "text":
        rules.minLength = 1
        rules.maxLength = 255
        break
      case "number":
        rules.type = "numeric"
        rules.min = 0
        break
      case "date":
        rules.format = field.format || "DD/MM/YYYY"
        rules.type = "date"
        break
      case "checkbox":
        rules.type = "boolean"
        rules.values = [true, false]
        break
    }

    if (field.required) {
      rules.required = true
    }

    return rules
  }

  static downloadTemplate(content: string, filename: string, type: "json" | "csv" = "json") {
    const mimeType = type === "json" ? "application/json" : "text/csv"
    const blob = new Blob([content], { type: mimeType })
    const url = URL.createObjectURL(blob)

    const link = document.createElement("a")
    link.href = url
    link.download = filename
    link.click()

    URL.revokeObjectURL(url)
  }
}
