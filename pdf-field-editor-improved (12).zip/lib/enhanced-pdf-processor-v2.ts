"use client"

import { googleVisionClient } from "./google-vision-client"
import { openaiClient } from "./openai-client"
import { openTyphoonClient } from "./opentyphoon-client"
import { pdfToImageConverter } from "./pdf-to-image"
import { huggingFaceClient } from "./huggingface-client"
import { tesseractClient } from "./tesseract-client"

// Enhanced PDF Processing with comprehensive OCR
export interface EnhancedProcessingResult {
  documentType: string
  confidence: number
  fields: DetectedField[]
  ocrText: string
  pages: number
  processingMethod: "google-vision" | "openai" | "opentyphoon" | "hybrid" | "mock" | "tesseract"
  textBlocks: any[]
  words: any[]
  provider: string
  statistics?: any
  detectedStructures?: any
}

export interface DetectedField {
  id: string
  name: string
  type: "text" | "number" | "date" | "checkbox" | "signature"
  x: number
  y: number
  width: number
  height: number
  page: number
  confidence: number
  required: boolean
  format?: string
  detectionMethod?: "google-vision" | "openai" | "opentyphoon" | "pattern-matching" | "tesseract"
  value?: string
}

export class EnhancedPDFProcessorV2 {
  private static instance: EnhancedPDFProcessorV2

  static getInstance(): EnhancedPDFProcessorV2 {
    if (!EnhancedPDFProcessorV2.instance) {
      EnhancedPDFProcessorV2.instance = new EnhancedPDFProcessorV2()
    }
    return EnhancedPDFProcessorV2.instance
  }

  async processDocument(file: File): Promise<EnhancedProcessingResult> {
    try {
      console.log("🚀 เริ่มประมวลผลเอกสาร:", file.name)

      // Step 1: Convert PDF to images
      const images = await pdfToImageConverter.convertAllPages(file)
      console.log("📄 แปลง PDF เป็นรูปภาพแล้ว:", images.length, "หน้า")

      // Step 2: OCR with comprehensive fallback chain
      const ocrResult = await this.performComprehensiveOCR(images[0])
      console.log("🔍 OCR เสร็จสิ้น:", ocrResult.confidence, "Provider:", ocrResult.provider)

      // Step 3: Classify document type
      const documentType = await this.classifyDocument(file.name, ocrResult.text)
      console.log("📋 จำแนกประเภทเอกสาร:", documentType.type)

      // Step 4: Comprehensive field detection
      const fields = await this.detectFieldsComprehensive(images[0], documentType.type, ocrResult)
      console.log("🎯 ตรวจจับฟิลด์แล้ว:", fields.length, "ฟิลด์")

      return {
        documentType: documentType.type,
        confidence: documentType.confidence,
        fields,
        ocrText: ocrResult.text,
        pages: images.length,
        processingMethod: "hybrid",
        textBlocks: ocrResult.blocks || [],
        words: ocrResult.words || [],
        provider: ocrResult.provider,
        statistics: ocrResult.statistics,
        detectedStructures: ocrResult.detectedStructures,
      }
    } catch (error) {
      console.error("❌ เกิดข้อผิดพลาดในการประมวลผล:", error)
      throw new Error("Failed to process PDF document")
    }
  }

  private async performComprehensiveOCR(imageData: string): Promise<any> {
    // Try Tesseract.js first (most comprehensive and reliable)
    try {
      console.log("🔍 ลอง Tesseract.js OCR (Comprehensive)...")
      const tesseractResult = await tesseractClient.performOCR(imageData)
      if (tesseractResult.confidence > 0.5 && tesseractResult.text.length > 10) {
        console.log("✅ ใช้ Tesseract.js OCR - ข้อความ:", tesseractResult.text.length, "ตัวอักษร")
        return { ...tesseractResult, provider: "tesseract" }
      }
    } catch (error) {
      console.warn("⚠️ Tesseract.js OCR ล้มเหลว:", error)
    }

    // Try Hugging Face Space second
    try {
      console.log("🚀 ลอง Hugging Face Space OCR...")
      const hfResult = await huggingFaceClient.performOCR(imageData)
      if (hfResult.confidence > 0.7) {
        console.log("✅ ใช้ Hugging Face Space OCR")
        return { ...hfResult, provider: "huggingface-space" }
      }
    } catch (error) {
      console.warn("⚠️ Hugging Face Space OCR ล้มเหลว:", error)
    }

    // Try OpenTyphoon third
    try {
      console.log("🔄 ลอง OpenTyphoon OCR...")
      const typhoonResult = await openTyphoonClient.performOCR(imageData)
      if (typhoonResult.confidence > 0.7) {
        console.log("✅ ใช้ OpenTyphoon OCR")
        return { ...typhoonResult, provider: "opentyphoon" }
      }
    } catch (error) {
      console.warn("⚠️ OpenTyphoon OCR ล้มเหลว:", error)
    }

    // Try Google Vision fourth
    try {
      console.log("🔄 ลอง Google Vision OCR...")
      const visionResult = await googleVisionClient.detectText(imageData)
      if (visionResult.confidence > 0.7) {
        console.log("✅ ใช้ Google Vision OCR")
        return { ...visionResult, provider: "google-vision" }
      }
    } catch (error) {
      console.warn("⚠️ Google Vision OCR ล้มเหลว:", error)
    }

    // Fallback to mock OCR
    console.log("🔄 ใช้ Mock OCR")
    return {
      text: "ข้อความตัวอย่างจาก OCR...",
      confidence: 0.8,
      blocks: [],
      words: [],
      provider: "mock",
    }
  }

  private async classifyDocument(fileName: string, ocrText: string): Promise<{ type: string; confidence: number }> {
    const documentTypes = [
      {
        pattern: /บต\.?\s*44|WP\.?\s*44|คำขอเปลี่ยนรายการ|work.*permit.*change|FORM\s*WP\.?\s*44/i,
        type: "work-permit-change",
        name: "คำขอเปลี่ยนรายการในใบอนุญาตทำงาน",
      },
      {
        pattern: /บต\.?\s*46|WP\.?\s*46|หนังสือรับรองการจ้าง|employment.*cert/i,
        type: "employment-cert",
        name: "หนังสือรับรองการจ้าง",
      },
      {
        pattern: /power.*attorney|หนังสือมอบอำนาจ/i,
        type: "power-of-attorney",
        name: "หนังสือมอบอำนาจ",
      },
      {
        pattern: /employment.*contract|สัญญาจ้าง/i,
        type: "employment-contract",
        name: "สัญญาจ้างงาน",
      },
    ]

    // Check filename first
    for (const docType of documentTypes) {
      if (docType.pattern.test(fileName)) {
        return { type: docType.type, confidence: 0.95 }
      }
    }

    // Check OCR text
    for (const docType of documentTypes) {
      if (docType.pattern.test(ocrText)) {
        return { type: docType.type, confidence: 0.85 }
      }
    }

    return { type: "unknown", confidence: 0.3 }
  }

  private async detectFieldsComprehensive(
    imageData: string,
    documentType: string,
    ocrResult: any,
  ): Promise<DetectedField[]> {
    const allFields: DetectedField[] = []

    // Method 1: Tesseract comprehensive field detection (primary method)
    try {
      console.log("🔍 ลอง Tesseract comprehensive field detection...")
      const tesseractFields = await tesseractClient.detectFormFields(imageData)
      if (tesseractFields.fields && tesseractFields.fields.length > 0) {
        console.log("🎯 Tesseract ตรวจพบ:", tesseractFields.fields.length, "ฟิลด์")
        allFields.push(...tesseractFields.fields)
      }
    } catch (error) {
      console.warn("⚠️ Tesseract field detection ล้มเหลว:", error)
    }

    // Method 2: Hugging Face Space form detection
    try {
      console.log("🚀 ลอง Hugging Face Space field detection...")
      const hfFields = await huggingFaceClient.detectFormFields(imageData)
      if (hfFields.fields && hfFields.fields.length > 0) {
        console.log("🎯 HF Space ตรวจพบ:", hfFields.fields.length, "ฟิลด์")
        allFields.push(...hfFields.fields)
      }
    } catch (error) {
      console.warn("⚠️ HF Space field detection ล้มเหลว:", error)
    }

    // Method 3: OpenTyphoon form detection
    try {
      console.log("🔍 ลอง OpenTyphoon field detection...")
      const typhoonFields = await openTyphoonClient.detectFormFields(imageData)
      if (typhoonFields.fields && typhoonFields.fields.length > 0) {
        console.log("🎯 OpenTyphoon ตรวจพบ:", typhoonFields.fields.length, "ฟิลด์")
        allFields.push(...typhoonFields.fields)
      }
    } catch (error) {
      console.warn("⚠️ OpenTyphoon field detection ล้มเหลว:", error)
    }

    // Method 4: Google Vision structure detection
    try {
      console.log("🔍 ลอง Google Vision field detection...")
      const visionFields = await googleVisionClient.detectDocumentStructure(imageData)
      if (visionFields.fields && visionFields.fields.length > 0) {
        console.log("🔍 Google Vision ตรวจพบ:", visionFields.fields.length, "ฟิลด์")
        allFields.push(
          ...visionFields.fields.map((field: any) => ({
            ...field,
            detectionMethod: "google-vision" as const,
          })),
        )
      }
    } catch (error) {
      console.warn("⚠️ Google Vision field detection ล้มเหลว:", error)
    }

    // Method 5: OpenAI field detection
    try {
      console.log("🤖 ลอง OpenAI field detection...")
      const openaiFields = await openaiClient.detectFields(imageData, documentType)
      if (openaiFields.fields && openaiFields.fields.length > 0) {
        console.log("🤖 OpenAI ตรวจพบ:", openaiFields.fields.length, "ฟิลด์")
        allFields.push(
          ...openaiFields.fields.map((field: any) => ({
            ...field,
            detectionMethod: "openai" as const,
          })),
        )
      }
    } catch (error) {
      console.warn("⚠️ OpenAI field detection ล้มเหลว:", error)
    }

    // Method 6: Pattern-based detection (fallback)
    if (allFields.length === 0) {
      console.log("🔄 ใช้ Pattern-based detection")
      const patternFields = this.generateFieldsFromPattern(documentType)
      allFields.push(
        ...patternFields.map((field: any) => ({
          ...field,
          detectionMethod: "pattern-matching" as const,
        })),
      )
    }

    // Merge and deduplicate fields
    return this.mergeAndDeduplicateFields(allFields)
  }

  private generateFieldsFromPattern(documentType: string): DetectedField[] {
    const fieldTemplates: Record<string, DetectedField[]> = {
      "work-permit-change": [
        {
          id: "wp-name",
          name: "ชื่อผู้ยื่นคำขอ",
          type: "text",
          x: 150,
          y: 120,
          width: 200,
          height: 20,
          page: 1,
          confidence: 0.8,
          required: true,
        },
        {
          id: "wp-nationality",
          name: "สัญชาติ",
          type: "text",
          x: 100,
          y: 150,
          width: 150,
          height: 20,
          page: 1,
          confidence: 0.8,
          required: true,
        },
        {
          id: "wp-permit-number",
          name: "เลขที่ใบอนุญาตทำงาน",
          type: "text",
          x: 200,
          y: 180,
          width: 180,
          height: 20,
          page: 1,
          confidence: 0.8,
          required: true,
        },
        {
          id: "wp-issue-date",
          name: "วันที่ออกใบอนุญาต",
          type: "date",
          x: 150,
          y: 210,
          width: 120,
          height: 20,
          page: 1,
          confidence: 0.8,
          required: true,
          format: "DD/MM/YYYY",
        },
        {
          id: "wp-employer-name",
          name: "ชื่อนายจ้าง",
          type: "text",
          x: 120,
          y: 240,
          width: 250,
          height: 20,
          page: 1,
          confidence: 0.8,
          required: true,
        },
        {
          id: "wp-signature",
          name: "ลายเซ็นผู้ยื่นคำขอ",
          type: "signature",
          x: 150,
          y: 350,
          width: 200,
          height: 50,
          page: 1,
          confidence: 0.8,
          required: true,
        },
      ],
      "employment-cert": [
        {
          id: "emp-employer-name",
          name: "ชื่อนายจ้าง",
          type: "text",
          x: 120,
          y: 200,
          width: 250,
          height: 20,
          page: 1,
          confidence: 0.8,
          required: true,
        },
        {
          id: "emp-address",
          name: "ที่อยู่สถานประกอบการ",
          type: "text",
          x: 100,
          y: 230,
          width: 300,
          height: 40,
          page: 1,
          confidence: 0.8,
          required: true,
        },
      ],
    }

    return fieldTemplates[documentType] || []
  }

  private mergeAndDeduplicateFields(fields: DetectedField[]): DetectedField[] {
    const merged: DetectedField[] = []
    const threshold = 50 // Distance threshold for considering fields as duplicates

    for (const field of fields) {
      const existing = merged.find((existing) => {
        const distance = Math.sqrt(Math.pow(existing.x - field.x, 2) + Math.pow(existing.y - field.y, 2))
        const nameMatch =
          existing.name.toLowerCase().includes(field.name.toLowerCase().substring(0, 5)) ||
          field.name.toLowerCase().includes(existing.name.toLowerCase().substring(0, 5))
        return distance < threshold && nameMatch
      })

      if (existing) {
        // Keep the field with higher confidence or more complete data
        if (field.confidence > existing.confidence || (field.value && !existing.value)) {
          const index = merged.indexOf(existing)
          merged[index] = {
            ...existing,
            ...field,
            confidence: Math.max(existing.confidence, field.confidence),
            value: field.value || existing.value,
          }
        }
      } else {
        merged.push(field)
      }
    }

    return merged
  }
}

// Export singleton instance
export const enhancedPDFProcessorV2 = EnhancedPDFProcessorV2.getInstance()
