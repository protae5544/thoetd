"use client"

import { googleVisionClient } from "./google-vision-client"
import { openaiClient } from "./openai-client"
import { pdfToImageConverter } from "./pdf-to-image"

// Enhanced PDF Processing with Google Vision + OpenAI
export interface EnhancedProcessingResult {
  documentType: string
  confidence: number
  fields: DetectedField[]
  ocrText: string
  pages: number
  processingMethod: "google-vision" | "openai" | "hybrid" | "mock"
  textBlocks: any[]
  words: any[]
}

export interface DetectedField {
  id: string
  name: string
  type: "text" | "number" | "date" | "checkbox" | "signature"
  x: number
  y: number
  width: number
  height: number
  page: number
  confidence: number
  required: boolean
  format?: string
  detectionMethod?: "google-vision" | "openai" | "pattern-matching"
}

export class EnhancedPDFProcessor {
  private static instance: EnhancedPDFProcessor

  static getInstance(): EnhancedPDFProcessor {
    if (!EnhancedPDFProcessor.instance) {
      EnhancedPDFProcessor.instance = new EnhancedPDFProcessor()
    }
    return EnhancedPDFProcessor.instance
  }

  async processDocument(file: File): Promise<EnhancedProcessingResult> {
    try {
      console.log("🚀 เริ่มประมวลผลเอกสาร:", file.name)

      // Step 1: Convert PDF to images
      const images = await pdfToImageConverter.convertAllPages(file)
      console.log("📄 แปลง PDF เป็นรูปภาพแล้ว:", images.length, "หน้า")

      // Step 2: OCR with Google Vision
      const ocrResult = await this.performOCR(images[0]) // Process first page
      console.log("🔍 OCR เสร็จสิ้น:", ocrResult.confidence)

      // Step 3: Classify document type
      const documentType = await this.classifyDocument(file.name, ocrResult.text)
      console.log("📋 จำแนกประเภทเอกสาร:", documentType.type)

      // Step 4: Detect fields using hybrid approach
      const fields = await this.detectFieldsHybrid(images[0], documentType.type, ocrResult)
      console.log("🎯 ตรวจจับฟิลด์แล้ว:", fields.length, "ฟิลด์")

      return {
        documentType: documentType.type,
        confidence: documentType.confidence,
        fields,
        ocrText: ocrResult.text,
        pages: images.length,
        processingMethod: "hybrid",
        textBlocks: ocrResult.blocks || [],
        words: ocrResult.words || [],
      }
    } catch (error) {
      console.error("❌ เกิดข้อผิดพลาดในการประมวลผล:", error)
      throw new Error("Failed to process PDF document")
    }
  }

  private async performOCR(imageData: string): Promise<any> {
    try {
      // Try Google Vision first
      const visionResult = await googleVisionClient.detectText(imageData)
      if (visionResult.confidence > 0.7) {
        console.log("✅ ใช้ Google Vision OCR")
        return visionResult
      }
    } catch (error) {
      console.warn("⚠️ Google Vision OCR ล้มเหลว:", error)
    }

    // Fallback to mock OCR
    console.log("🔄 ใช้ Mock OCR")
    return {
      text: "ข้อความตัวอย่างจาก OCR...",
      confidence: 0.8,
      blocks: [],
      words: [],
    }
  }

  private async classifyDocument(fileName: string, ocrText: string): Promise<{ type: string; confidence: number }> {
    const documentTypes = [
      {
        pattern: /บต\.?\s*44|WP\.?\s*44|คำขอเปลี่ยนรายการ|work.*permit.*change/i,
        type: "work-permit-change",
        name: "คำขอเปลี่ยนรายการในใบอนุญาตทำงาน",
      },
      {
        pattern: /บต\.?\s*46|WP\.?\s*46|หนังสือรับรองการจ้าง|employment.*cert/i,
        type: "employment-cert",
        name: "หนังสือรับรองการจ้าง",
      },
      {
        pattern: /power.*attorney|หนังสือมอบอำนาจ/i,
        type: "power-of-attorney",
        name: "หนังสือมอบอำนาจ",
      },
      {
        pattern: /employment.*contract|สัญญาจ้าง/i,
        type: "employment-contract",
        name: "สัญญาจ้างงาน",
      },
    ]

    // Check filename first
    for (const docType of documentTypes) {
      if (docType.pattern.test(fileName)) {
        return { type: docType.type, confidence: 0.95 }
      }
    }

    // Check OCR text
    for (const docType of documentTypes) {
      if (docType.pattern.test(ocrText)) {
        return { type: docType.type, confidence: 0.85 }
      }
    }

    return { type: "unknown", confidence: 0.3 }
  }

  private async detectFieldsHybrid(imageData: string, documentType: string, ocrResult: any): Promise<DetectedField[]> {
    const allFields: DetectedField[] = []

    try {
      // Method 1: Google Vision structure detection
      const visionFields = await googleVisionClient.detectDocumentStructure(imageData)
      if (visionFields.fields && visionFields.fields.length > 0) {
        console.log("🔍 Google Vision ตรวจพบ:", visionFields.fields.length, "ฟิลด์")
        allFields.push(
          ...visionFields.fields.map((field: any) => ({
            ...field,
            detectionMethod: "google-vision" as const,
          })),
        )
      }
    } catch (error) {
      console.warn("⚠️ Google Vision field detection ล้มเหลว:", error)
    }

    try {
      // Method 2: OpenAI field detection
      const openaiFields = await openaiClient.detectFields(imageData, documentType)
      if (openaiFields.fields && openaiFields.fields.length > 0) {
        console.log("🤖 OpenAI ตรวจพบ:", openaiFields.fields.length, "ฟิลด์")
        allFields.push(
          ...openaiFields.fields.map((field: any) => ({
            ...field,
            detectionMethod: "openai" as const,
          })),
        )
      }
    } catch (error) {
      console.warn("⚠️ OpenAI field detection ล้มเหลว:", error)
    }

    // Method 3: Pattern-based detection (fallback)
    if (allFields.length === 0) {
      console.log("🔄 ใช้ Pattern-based detection")
      const patternFields = this.generateFieldsFromPattern(documentType)
      allFields.push(
        ...patternFields.map((field: any) => ({
          ...field,
          detectionMethod: "pattern-matching" as const,
        })),
      )
    }

    // Merge and deduplicate fields
    return this.mergeAndDeduplicateFields(allFields)
  }

  private generateFieldsFromPattern(documentType: string): DetectedField[] {
    const fieldTemplates: Record<string, DetectedField[]> = {
      "work-permit-change": [
        {
          id: "wp-name",
          name: "ชื่อผู้ยื่นคำขอ",
          type: "text",
          x: 150,
          y: 120,
          width: 200,
          height: 20,
          page: 1,
          confidence: 0.8,
          required: true,
        },
        {
          id: "wp-nationality",
          name: "สัญชาติ",
          type: "text",
          x: 100,
          y: 150,
          width: 150,
          height: 20,
          page: 1,
          confidence: 0.8,
          required: true,
        },
        {
          id: "wp-permit-number",
          name: "เลขที่ใบอนุญาตทำงาน",
          type: "text",
          x: 200,
          y: 180,
          width: 180,
          height: 20,
          page: 1,
          confidence: 0.8,
          required: true,
        },
        {
          id: "wp-issue-date",
          name: "วันที่ออกใบอนุญาต",
          type: "date",
          x: 150,
          y: 210,
          width: 120,
          height: 20,
          page: 1,
          confidence: 0.8,
          required: true,
          format: "DD/MM/YYYY",
        },
      ],
      "employment-cert": [
        {
          id: "emp-employer-name",
          name: "ชื่อนายจ้าง",
          type: "text",
          x: 120,
          y: 200,
          width: 250,
          height: 20,
          page: 1,
          confidence: 0.8,
          required: true,
        },
        {
          id: "emp-address",
          name: "ที่อยู่สถานประกอบการ",
          type: "text",
          x: 100,
          y: 230,
          width: 300,
          height: 40,
          page: 1,
          confidence: 0.8,
          required: true,
        },
      ],
    }

    return fieldTemplates[documentType] || []
  }

  private mergeAndDeduplicateFields(fields: DetectedField[]): DetectedField[] {
    const merged: DetectedField[] = []
    const threshold = 50 // Distance threshold for considering fields as duplicates

    for (const field of fields) {
      const existing = merged.find((existing) => {
        const distance = Math.sqrt(Math.pow(existing.x - field.x, 2) + Math.pow(existing.y - field.y, 2))
        return distance < threshold && existing.name.includes(field.name.substring(0, 5))
      })

      if (existing) {
        // Keep the field with higher confidence
        if (field.confidence > existing.confidence) {
          const index = merged.indexOf(existing)
          merged[index] = field
        }
      } else {
        merged.push(field)
      }
    }

    return merged
  }
}

// Export singleton instance
export const enhancedPDFProcessor = EnhancedPDFProcessor.getInstance()
