"use client"

// Google Vision API Client for OCR and text detection
export class GoogleVisionClient {
  private apiKey: string
  private baseUrl = "https://vision.googleapis.com/v1"

  constructor(apiKey: string) {
    this.apiKey = apiKey
  }

  async detectText(imageData: string): Promise<any> {
    if (!this.apiKey || this.apiKey === "demo-key") {
      // Return mock data if no API key
      return this.getMockTextDetection()
    }

    try {
      const response = await fetch(`${this.baseUrl}/images:annotate?key=${this.apiKey}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          requests: [
            {
              image: {
                content: imageData,
              },
              features: [
                {
                  type: "DOCUMENT_TEXT_DETECTION",
                  maxResults: 50,
                },
                {
                  type: "TEXT_DETECTION",
                  maxResults: 50,
                },
              ],
              imageContext: {
                languageHints: ["th", "en"],
              },
            },
          ],
        }),
      })

      if (!response.ok) {
        throw new Error(`Google Vision API error: ${response.status}`)
      }

      const data = await response.json()
      return this.processVisionResponse(data)
    } catch (error) {
      console.error("Google Vision API error:", error)
      // Fallback to mock data
      return this.getMockTextDetection()
    }
  }

  async detectDocumentStructure(imageData: string): Promise<any> {
    try {
      const response = await fetch(`${this.baseUrl}/images:annotate?key=${this.apiKey}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          requests: [
            {
              image: {
                content: imageData,
              },
              features: [
                {
                  type: "DOCUMENT_TEXT_DETECTION",
                  maxResults: 1,
                },
              ],
              imageContext: {
                languageHints: ["th", "en"],
              },
            },
          ],
        }),
      })

      if (!response.ok) {
        throw new Error(`Google Vision API error: ${response.status}`)
      }

      const data = await response.json()
      return this.extractFormFields(data)
    } catch (error) {
      console.error("Google Vision document structure error:", error)
      return { fields: [], confidence: 0.5 }
    }
  }

  private processVisionResponse(data: any): any {
    const responses = data.responses || []
    if (responses.length === 0) {
      return { text: "", confidence: 0 }
    }

    const response = responses[0]
    const fullTextAnnotation = response.fullTextAnnotation

    if (!fullTextAnnotation) {
      return { text: "", confidence: 0 }
    }

    return {
      text: fullTextAnnotation.text || "",
      confidence: this.calculateConfidence(response.textAnnotations || []),
      blocks: this.extractTextBlocks(fullTextAnnotation),
      words: this.extractWords(response.textAnnotations || []),
    }
  }

  private extractFormFields(data: any): any {
    const responses = data.responses || []
    if (responses.length === 0) {
      return { fields: [], confidence: 0 }
    }

    const response = responses[0]
    const fullTextAnnotation = response.fullTextAnnotation

    if (!fullTextAnnotation) {
      return { fields: [], confidence: 0 }
    }

    const fields = this.analyzeTextForFields(fullTextAnnotation)
    return {
      fields,
      confidence: 0.85,
      ocrText: fullTextAnnotation.text || "",
    }
  }

  private analyzeTextForFields(textAnnotation: any): any[] {
    const text = textAnnotation.text || ""
    const pages = textAnnotation.pages || []
    const fields: any[] = []

    // Thai form field patterns
    const fieldPatterns = [
      {
        pattern: /ชื่อ[\s\-_]*(?:ผู้ยื่นคำขอ|ผู้ขอ|นาย|นาง|นางสาว)?[\s\-_]*:?[\s\-_]*$/gim,
        name: "ชื่อผู้ยื่นคำขอ",
        type: "text",
      },
      {
        pattern: /สัญชาติ[\s\-_]*:?[\s\-_]*$/gim,
        name: "สัญชาติ",
        type: "text",
      },
      {
        pattern: /เลขที่[\s\-_]*(?:ใบอนุญาต|ใบอนุญาตทำงาน)?[\s\-_]*:?[\s\-_]*$/gim,
        name: "เลขที่ใบอนุญาตทำงาน",
        type: "text",
      },
      {
        pattern: /วันที่[\s\-_]*(?:ออก|ออกใบอนุญาต)?[\s\-_]*:?[\s\-_]*$/gim,
        name: "วันที่ออกใบอนุญาต",
        type: "date",
      },
      {
        pattern: /ที่อยู่[\s\-_]*(?:สถานประกอบการ|บริษัท|ห้างร้าน)?[\s\-_]*:?[\s\-_]*$/gim,
        name: "ที่อยู่สถานประกอบการ",
        type: "text",
      },
      {
        pattern: /ประเภท[\s\-_]*(?:กิจการ|ธุรกิจ|งาน)?[\s\-_]*:?[\s\-_]*$/gim,
        name: "ประเภทกิจการ",
        type: "text",
      },
      {
        pattern: /ลายเซ็น[\s\-_]*(?:ผู้ยื่นคำขอ|ผู้ขอ)?[\s\-_]*:?[\s\-_]*$/gim,
        name: "ลายเซ็นผู้ยื่นคำขอ",
        type: "signature",
      },
    ]

    // Analyze each page
    pages.forEach((page: any, pageIndex: number) => {
      const blocks = page.blocks || []

      blocks.forEach((block: any) => {
        const blockText = this.extractBlockText(block)

        fieldPatterns.forEach((pattern, patternIndex) => {
          const matches = blockText.match(pattern.pattern)
          if (matches) {
            matches.forEach((match) => {
              const boundingBox = this.getBlockBoundingBox(block)
              if (boundingBox) {
                fields.push({
                  id: `field-${pageIndex}-${patternIndex}-${fields.length}`,
                  name: pattern.name,
                  type: pattern.type,
                  x: boundingBox.x,
                  y: boundingBox.y + boundingBox.height + 5, // Position below the label
                  width: Math.max(150, boundingBox.width),
                  height: pattern.type === "signature" ? 50 : 25,
                  page: pageIndex + 1,
                  confidence: 0.8 + Math.random() * 0.15, // Random confidence between 0.8-0.95
                  required: this.isRequiredField(pattern.name),
                  format: pattern.type === "date" ? "DD/MM/YYYY" : undefined,
                })
              }
            })
          }
        })
      })
    })

    return fields
  }

  private extractBlockText(block: any): string {
    const paragraphs = block.paragraphs || []
    return paragraphs
      .map((paragraph: any) => {
        const words = paragraph.words || []
        return words
          .map((word: any) => {
            const symbols = word.symbols || []
            return symbols.map((symbol: any) => symbol.text || "").join("")
          })
          .join(" ")
      })
      .join(" ")
  }

  private getBlockBoundingBox(block: any): any {
    const boundingBox = block.boundingBox
    if (!boundingBox || !boundingBox.vertices || boundingBox.vertices.length < 4) {
      return null
    }

    const vertices = boundingBox.vertices
    const xs = vertices.map((v: any) => v.x || 0)
    const ys = vertices.map((v: any) => v.y || 0)

    return {
      x: Math.min(...xs),
      y: Math.min(...ys),
      width: Math.max(...xs) - Math.min(...xs),
      height: Math.max(...ys) - Math.min(...ys),
    }
  }

  private isRequiredField(fieldName: string): boolean {
    const requiredFields = ["ชื่อผู้ยื่นคำขอ", "สัญชาติ", "เลขที่ใบอนุญาตทำงาน", "วันที่ออกใบอนุญาต"]
    return requiredFields.includes(fieldName)
  }

  private calculateConfidence(textAnnotations: any[]): number {
    if (textAnnotations.length === 0) return 0

    const confidences = textAnnotations
      .slice(1) // Skip the first annotation which is the full text
      .map((annotation) => annotation.confidence || 0.8)

    return confidences.reduce((sum, conf) => sum + conf, 0) / confidences.length
  }

  private extractTextBlocks(fullTextAnnotation: any): any[] {
    const pages = fullTextAnnotation.pages || []
    const blocks: any[] = []

    pages.forEach((page: any) => {
      const pageBlocks = page.blocks || []
      pageBlocks.forEach((block: any) => {
        const text = this.extractBlockText(block)
        const boundingBox = this.getBlockBoundingBox(block)

        if (text.trim() && boundingBox) {
          blocks.push({
            text: text.trim(),
            boundingBox,
            confidence: 0.9,
          })
        }
      })
    })

    return blocks
  }

  private extractWords(textAnnotations: any[]): any[] {
    return textAnnotations.slice(1).map((annotation) => ({
      text: annotation.description || "",
      boundingBox: this.getBoundingBoxFromVertices(annotation.boundingPoly?.vertices || []),
      confidence: annotation.confidence || 0.8,
    }))
  }

  private getBoundingBoxFromVertices(vertices: any[]): any {
    if (vertices.length < 4) return null

    const xs = vertices.map((v: any) => v.x || 0)
    const ys = vertices.map((v: any) => v.y || 0)

    return {
      x: Math.min(...xs),
      y: Math.min(...ys),
      width: Math.max(...xs) - Math.min(...xs),
      height: Math.max(...ys) - Math.min(...ys),
    }
  }

  private getMockTextDetection(): any {
    return {
      text: `คำขอเปลี่ยนรายการในใบอนุญาตทำงาน
      
ชื่อผู้ยื่นคำขอ: _________________
สัญชาติ: _________________
เลขที่ใบอนุญาตทำงาน: _________________
วันที่ออกใบอนุญาต: _________________
ที่อยู่สถานประกอบการ: _________________
ประเภทกิจการ: _________________

ลายเซ็นผู้ยื่นคำขอ: _________________`,
      confidence: 0.85,
      blocks: [],
      words: [],
    }
  }

  // Test API connection
  async testConnection(): Promise<{ success: boolean; message: string }> {
    if (!this.apiKey || this.apiKey === "demo-key") {
      return {
        success: false,
        message: "ไม่พบ Google Vision API Key กรุณาตั้งค่า NEXT_PUBLIC_GOOGLE_VISION_API_KEY",
      }
    }

    try {
      // Test with a simple image (1x1 pixel white PNG)
      const testImage =
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/5+hHgAHggJ/PchI7wAAAABJRU5ErkJggg=="

      const response = await fetch(`${this.baseUrl}/images:annotate?key=${this.apiKey}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          requests: [
            {
              image: {
                content: testImage,
              },
              features: [
                {
                  type: "TEXT_DETECTION",
                  maxResults: 1,
                },
              ],
            },
          ],
        }),
      })

      if (response.ok) {
        return {
          success: true,
          message: "เชื่อมต่อ Google Vision API สำเร็จ",
        }
      } else {
        const errorData = await response.json().catch(() => ({}))
        return {
          success: false,
          message: `Google Vision API Error: ${response.status} - ${errorData.error?.message || "กรุณาตรวจสอบ API Key"}`,
        }
      }
    } catch (error) {
      return {
        success: false,
        message: `การเชื่อมต่อล้มเหลว: ${error instanceof Error ? error.message : "Unknown error"}`,
      }
    }
  }
}

// Export singleton instance
export const googleVisionClient = new GoogleVisionClient(process.env.NEXT_PUBLIC_GOOGLE_VISION_API_KEY || "demo-key")
