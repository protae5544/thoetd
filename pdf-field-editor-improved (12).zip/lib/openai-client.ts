"use client"

// OpenAI Client for field detection
export class OpenAIClient {
  private apiKey: string
  private baseUrl = "https://api.openai.com/v1"

  constructor(apiKey: string) {
    this.apiKey = apiKey
  }

  async detectFields(imageData: string, documentType: string): Promise<any> {
    if (!this.apiKey || this.apiKey === "demo-key") {
      // Return mock data if no API key
      return this.getMockFieldDetection(documentType)
    }

    try {
      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${this.apiKey}`,
        },
        body: JSON.stringify({
          model: "gpt-4-vision-preview",
          messages: [
            {
              role: "system",
              content: this.getSystemPrompt(documentType),
            },
            {
              role: "user",
              content: [
                {
                  type: "text",
                  text: "กรุณาวิเคราะห์เอกสารนี้และตรวจจับฟิลด์ที่สามารถกรอกข้อมูลได้ทั้งหมด",
                },
                {
                  type: "image_url",
                  image_url: {
                    url: `data:image/jpeg;base64,${imageData}`,
                  },
                },
              ],
            },
          ],
          max_tokens: 1000,
          temperature: 0.1,
        }),
      })

      if (!response.ok) {
        throw new Error(`OpenAI API error: ${response.status}`)
      }

      const data = await response.json()
      const content = data.choices[0]?.message?.content

      try {
        return JSON.parse(content)
      } catch {
        // If parsing fails, return mock data
        return this.getMockFieldDetection(documentType)
      }
    } catch (error) {
      console.error("OpenAI API error:", error)
      // Fallback to mock data
      return this.getMockFieldDetection(documentType)
    }
  }

  private getSystemPrompt(documentType: string): string {
    const prompts: Record<string, string> = {
      "work-permit-change": `
        คุณเป็นผู้เชี่ยวชาญในการวิเคราะห์แบบฟอร์มคำขอเปลี่ยนรายการในใบอนุญาตทำงาน (บต.44)
        
        กรุณาตรวจจับฟิลด์ที่สามารถกรอกข้อมูลได้ทั้งหมด และส่งคืนในรูปแบบ JSON:
        
        {
          "fields": [
            {
              "id": "unique_id",
              "name": "ชื่อฟิลด์ภาษาไทย",
              "type": "text|number|date|checkbox|signature",
              "x": 0,
              "y": 0,
              "width": 0,
              "height": 0,
              "page": 1,
              "confidence": 0.9,
              "required": true
            }
          ]
        }
      `,
      "employment-cert": `
        คุณเป็นผู้เชี่ยวชาญในการวิเคราะห์แบบฟอร์มหนังสือรับรองการจ้าง (บต.46)
        
        กรุณาตรวจจับฟิลด์ที่สามารถกรอกข้อมูลได้ทั้งหมด และส่งคืนในรูปแบบ JSON เดียวกัน
      `,
      default: `
        คุณเป็นผู้เชี่ยวชาญในการวิเคราะห์เอกสารราชการไทย
        
        กรุณาตรวจจับฟิลด์ที่สามารถกรอกข้อมูลได้ทั้งหมด และส่งคืนในรูปแบบ JSON
      `,
    }

    return prompts[documentType] || prompts.default
  }

  private getMockFieldDetection(documentType: string): any {
    const mockFields: Record<string, any> = {
      "work-permit-change": {
        fields: [
          {
            id: "wp-name",
            name: "ชื่อผู้ยื่นคำขอ",
            type: "text",
            x: 150,
            y: 120,
            width: 200,
            height: 20,
            page: 1,
            confidence: 0.9,
            required: true,
          },
          {
            id: "wp-nationality",
            name: "สัญชาติ",
            type: "text",
            x: 100,
            y: 150,
            width: 150,
            height: 20,
            page: 1,
            confidence: 0.85,
            required: true,
          },
          {
            id: "wp-permit-number",
            name: "เลขที่ใบอนุญาตทำงาน",
            type: "text",
            x: 200,
            y: 180,
            width: 180,
            height: 20,
            page: 1,
            confidence: 0.88,
            required: true,
          },
        ],
      },
      "employment-cert": {
        fields: [
          {
            id: "emp-employer",
            name: "ชื่อนายจ้าง",
            type: "text",
            x: 120,
            y: 200,
            width: 250,
            height: 20,
            page: 1,
            confidence: 0.92,
            required: true,
          },
          {
            id: "emp-address",
            name: "ที่อยู่สถานประกอบการ",
            type: "text",
            x: 100,
            y: 230,
            width: 300,
            height: 40,
            page: 1,
            confidence: 0.89,
            required: true,
          },
        ],
      },
    }

    return mockFields[documentType] || { fields: [] }
  }

  // Test API connection
  async testConnection(): Promise<{ success: boolean; message: string }> {
    if (!this.apiKey || this.apiKey === "demo-key") {
      return {
        success: false,
        message: "ไม่พบ OpenAI API Key กรุณาตั้งค่า NEXT_PUBLIC_OPENAI_API_KEY",
      }
    }

    try {
      const response = await fetch(`${this.baseUrl}/models`, {
        headers: {
          Authorization: `Bearer ${this.apiKey}`,
        },
      })

      if (response.ok) {
        return {
          success: true,
          message: "เชื่อมต่อ OpenAI API สำเร็จ",
        }
      } else {
        return {
          success: false,
          message: `OpenAI API Error: ${response.status} - กรุณาตรวจสอบ API Key`,
        }
      }
    } catch (error) {
      return {
        success: false,
        message: `การเชื่อมต่อล้มเหลว: ${error instanceof Error ? error.message : "Unknown error"}`,
      }
    }
  }
}

// Export singleton instance
export const openaiClient = new OpenAIClient(process.env.NEXT_PUBLIC_OPENAI_API_KEY || "demo-key")
